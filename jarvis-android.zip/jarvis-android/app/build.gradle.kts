plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "app.jarvis"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.jarvis"
        minSdk = 28
        targetSdk = 34
        versionCode = 3
        versionName = "0.3.1"
    }

    // Firma fija: así cada APK nueva se instala encima de la anterior sin perder permisos ni ajustes.
    signingConfigs {
        getByName("debug") {
            storeFile = file("jarvis-debug.keystore")
            storePassword = "android"
            keyAlias = "jarvis"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Sin dependencias a propósito: solo APIs del sistema Android.
dependencies {
}
