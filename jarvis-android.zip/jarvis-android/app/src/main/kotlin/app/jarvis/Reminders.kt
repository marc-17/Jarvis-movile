package app.jarvis

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Recordatorios: "recuérdame mañana a las 9 llamar a Marcos". Suena una notificación y Jarvis lo dice en voz alta. */
object Reminders {
    data class Reminder(val id: Int, val at: Long, val text: String)

    class Parsed(val at: Long?, val what: String)

    private const val CHANNEL = "jarvis_reminders"

    fun load(ctx: Context): MutableList<Reminder> {
        val out = ArrayList<Reminder>()
        try {
            val a = JSONArray(Prefs.get(ctx, "reminders", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Reminder(o.getInt("id"), o.getLong("at"), o.getString("text")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, list: List<Reminder>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("at", it.at).put("text", it.text)) }
        Prefs.put(ctx, "reminders", a.toString())
    }

    private fun pending(ctx: Context, id: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, id, Intent(ctx, ReminderReceiver::class.java).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun schedule(ctx: Context, r: Reminder) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        val pi = pending(ctx, r.id)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, r.at, pi)
        }
    }

    fun add(ctx: Context, at: Long, text: String): Reminder {
        val r = Reminder(Prefs.nextId(ctx), at, text)
        val l = load(ctx)
        l.add(r)
        save(ctx, l)
        schedule(ctx, r)
        return r
    }

    fun remove(ctx: Context, id: Int) {
        val am = ctx.getSystemService(AlarmManager::class.java)
        am.cancel(pending(ctx, id))
        save(ctx, load(ctx).filter { it.id != id })
    }

    fun clearAll(ctx: Context) {
        load(ctx).forEach { remove(ctx, it.id) }
    }

    fun rescheduleAll(ctx: Context) {
        val now = System.currentTimeMillis()
        load(ctx).forEach { if (it.at > now) schedule(ctx, it) }
        save(ctx, load(ctx).filter { it.at > now })
    }

    /** Lo llama el receptor cuando llega la hora. */
    fun fire(ctx: Context, id: Int) {
        val r = load(ctx).firstOrNull { it.id == id } ?: return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Recordatorios de Jarvis", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(ctx, id, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = android.app.Notification.Builder(ctx, CHANNEL)
            .setContentTitle("Recordatorio de Jarvis")
            .setContentText(r.text)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try { nm.notify(100000 + id, n) } catch (_: Exception) {}
        Speaker.say(ctx, "Recordatorio: ${r.text}")
        save(ctx, load(ctx).filter { it.id != id })
    }

    fun whenText(at: Long): String {
        val now = Calendar.getInstance()
        val t = Calendar.getInstance().apply { timeInMillis = at }
        val hour = SimpleDateFormat("H:mm", Locale("es", "ES")).format(Date(at))
        val dayDiff = ((t.get(Calendar.YEAR) * 366 + t.get(Calendar.DAY_OF_YEAR)) - (now.get(Calendar.YEAR) * 366 + now.get(Calendar.DAY_OF_YEAR)))
        return when (dayDiff) {
            0 -> "hoy a las $hour"
            1 -> "mañana a las $hour"
            else -> SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES")).format(Date(at)) + " a las $hour"
        }
    }

    fun list(ctx: Context): String {
        val l = load(ctx).sortedBy { it.at }
        if (l.isEmpty()) return "No tienes recordatorios."
        return "Tienes ${l.size}. " + l.joinToString(". ") { "${whenText(it.at)}: ${it.text}" }
    }

    // ---------- Crear desde una frase ----------

    private const val NUM = "\\d{1,2}|una|un|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|once|doce|quince|veinte|treinta|cuarenta|cincuenta|sesenta"
    private val days = listOf("lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo")
    private val calDays = listOf(Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY, Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY)

    /** [c] ya normalizado (sin tildes). Devuelve la hora (o null si falta) y el "qué". */
    fun parse(c: String, nowMs: Long = System.currentTimeMillis()): Parsed {
        var s = " $c "
        // 1) Relativo: "dentro de 10 minutos", "en media hora"
        var rel: Long? = null
        Regex(" (?:dentro de|en) ($NUM) (minutos?|horas?|dias?|semanas?) ").find(s)?.let {
            val n = Text.number(it.groupValues[1]) ?: 0
            val unit = it.groupValues[2]
            rel = n * when {
                unit.startsWith("min") -> 60_000L
                unit.startsWith("hora") -> 3_600_000L
                unit.startsWith("dia") -> 86_400_000L
                else -> 7 * 86_400_000L
            }
            s = s.replace(it.value, " ")
        }
        Regex(" (?:dentro de|en) media hora ").find(s)?.let { rel = 1_800_000L; s = s.replace(it.value, " ") }

        // 2) Hora: "a las 9", "a las 9 y media", "a las 9 de la noche", "al mediodia"
        var hour: Int? = null
        var minute = 0
        var part = ""
        var plusDay = 0
        Regex(" a (?:las?|la) ($NUM)(?: y (media|cuarto|\\d{1,2})| menos (cuarto|\\d{1,2})| (\\d{2}))?(?: de la (manana|tarde|noche|madrugada)| del (mediodia))? ").find(s)?.let {
            hour = Text.number(it.groupValues[1])
            when {
                it.groupValues[2] == "media" -> minute = 30
                it.groupValues[2] == "cuarto" -> minute = 15
                it.groupValues[2].isNotEmpty() -> minute = it.groupValues[2].toIntOrNull() ?: 0
                it.groupValues[3] == "cuarto" -> { minute = 45; hour = (hour ?: 1) - 1 }
                it.groupValues[3].isNotEmpty() -> { minute = 60 - (it.groupValues[3].toIntOrNull() ?: 0); hour = (hour ?: 1) - 1 }
                it.groupValues[4].isNotEmpty() -> minute = it.groupValues[4].toIntOrNull() ?: 0
            }
            part = it.groupValues[5]
            s = s.replace(it.value, " ")
        }
        Regex(" (?:al mediodia|a mediodia) ").find(s)?.let { hour = 12; minute = 0; part = "x"; s = s.replace(it.value, " ") }
        Regex(" a medianoche ").find(s)?.let { hour = 0; minute = 0; part = "x"; plusDay = 1; s = s.replace(it.value, " ") }

        // 3) Parte del día suelta: "esta noche", "esta tarde"
        Regex(" (?:esta|por la) (manana|tarde|noche) ").find(s)?.let {
            if (part.isEmpty()) part = it.groupValues[1]
            if (hour == null && rel == null) {
                hour = when (it.groupValues[1]) { "manana" -> 9; "tarde" -> 17; else -> 21 }
                part = "x"
            }
            s = s.replace(it.value, " ")
        }

        // 4) Día
        var dayOffset: Int? = null
        var weekday: Int? = null
        Regex(" pasado manana ").find(s)?.let { dayOffset = 2; s = s.replace(it.value, " ") }
        Regex(" manana ").find(s)?.let { if (dayOffset == null) dayOffset = 1; s = s.replace(it.value, " ") }
        Regex(" hoy ").find(s)?.let { if (dayOffset == null) dayOffset = 0; s = s.replace(it.value, " ") }
        Regex(" (?:el |este )?(?:proximo )?(${days.joinToString("|")}) ").find(s)?.let {
            weekday = calDays[days.indexOf(it.groupValues[1])]
            s = s.replace(it.value, " ")
        }

        val what = s.trim().replace(Regex("^(que |de |para |a |me )+"), "").replace(Regex(" (que|de|para|a)$"), "").trim()

        // Calcular la fecha
        val cal = Calendar.getInstance().apply { timeInMillis = nowMs; set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        if (rel != null) return Parsed(nowMs + rel!!, what)
        val h0 = hour ?: return Parsed(null, what)
        var h = h0
        when (part) {
            "tarde", "noche" -> if (h < 12) h += 12
            "manana" -> if (h == 12) h = 0
        }
        if (part == "noche" && h0 == 12) { h = 0; plusDay = 1 }
        val noPart = part.isEmpty()
        if (noPart && h in 1..6) h += 12
        if (dayOffset != null) cal.add(Calendar.DAY_OF_YEAR, dayOffset!!)
        else if (weekday != null) {
            var add = (weekday!! - cal.get(Calendar.DAY_OF_WEEK) + 7) % 7
            cal.set(Calendar.HOUR_OF_DAY, h); cal.set(Calendar.MINUTE, minute)
            if (add == 0 && cal.timeInMillis <= nowMs) add = 7
            cal.add(Calendar.DAY_OF_YEAR, add)
        }
        cal.add(Calendar.DAY_OF_YEAR, plusDay)
        cal.set(Calendar.HOUR_OF_DAY, h)
        cal.set(Calendar.MINUTE, minute)
        if (cal.timeInMillis <= nowMs && dayOffset == null && weekday == null) {
            // Hoy ya pasó: si era hora ambigua prueba la tarde; si no, mañana
            if (noPart && h < 12) {
                cal.set(Calendar.HOUR_OF_DAY, h + 12)
            }
            if (cal.timeInMillis <= nowMs) { cal.set(Calendar.HOUR_OF_DAY, h); cal.add(Calendar.DAY_OF_YEAR, 1) }
        }
        return Parsed(cal.timeInMillis, what)
    }

    /** "recuérdame mañana a las 9 llamar a Marcos". [c] normalizado. Pregunta lo que falte (qué / cuándo). */
    fun fromSpeech(ctx: Context, c: String, reply: (String) -> Unit, depth: Int = 0) {
        val p = parse(c)
        if (p.what.isBlank() && depth < 2) {
            Conversation.ask { cc, ans, r -> fromSpeech(cc, c + " " + Text.norm(ans), r, depth + 1) }
            reply("¿Qué quieres que te recuerde?")
            return
        }
        if (p.at == null) {
            if (depth >= 2) { reply("No he entendido cuándo. Prueba otra vez."); return }
            Conversation.ask { cc, ans, r ->
                val n = Text.norm(ans)
                val t = if (n.startsWith("a las") || n.startsWith("a la ") || n.startsWith("en ") || n.startsWith("dentro") || n.startsWith("al ")) n else "a las $n"
                fromSpeech(cc, "$c $t", r, depth + 1)
            }
            reply("¿Cuándo te lo recuerdo?")
            return
        }
        finish(ctx, p.at, p.what, reply)
    }

    private fun finish(ctx: Context, at: Long?, what: String, reply: (String) -> Unit) {
        if (what.isBlank()) { reply("¿Qué quieres que te recuerde?"); return }
        if (at == null) { reply("No he entendido cuándo."); return }
        if (at <= System.currentTimeMillis()) { reply("Esa hora ya ha pasado."); return }
        add(ctx, at, what)
        reply("Vale, te lo recuerdo ${whenText(at)}: $what")
    }

    /** Cuando lo decide Gemini: when = "yyyy-MM-ddTHH:mm". */
    fun addFromAi(ctx: Context, text: String, whenIso: String, reply: (String) -> Unit) {
        val at = try {
            SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US).parse(whenIso.trim())?.time
        } catch (e: Exception) {
            null
        }
        finish(ctx, at, text.trim(), reply)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getIntExtra("id", -1)
        if (id >= 0) Reminders.fire(context.applicationContext, id)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Reminders.rescheduleAll(context.applicationContext)
    }
}
