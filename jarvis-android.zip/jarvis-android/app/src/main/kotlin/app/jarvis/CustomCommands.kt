package app.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Comandos que añades tú desde la app: "frase" -> acción. Se guardan en el móvil (SharedPreferences). */
data class Custom(val phrase: String, val type: String, val value: String) {
    companion object {
        const val APP = "APP"   // abrir una app (nombre o paquete)
        const val URL = "URL"   // abrir un enlace / deep link
        const val CALL = "CALL" // llamar a un número o contacto
        const val SAY = "SAY"   // solo decir un texto
    }
}

object CustomCommands {
    private const val PREFS = "jarvis"
    private const val KEY = "custom"

    fun load(ctx: Context): MutableList<Custom> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val out = ArrayList<Custom>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Custom(o.getString("phrase"), o.getString("type"), o.getString("value")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(ctx: Context, list: List<Custom>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("phrase", it.phrase).put("type", it.type).put("value", it.value))
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    /** Busca un comando tuyo que coincida con lo dicho (igual, o empezando por la frase). */
    fun find(ctx: Context, normalized: String): Custom? =
        load(ctx).firstOrNull {
            val p = Text.norm(it.phrase)
            p.isNotEmpty() && (normalized == p || normalized.startsWith("$p "))
        }
}
