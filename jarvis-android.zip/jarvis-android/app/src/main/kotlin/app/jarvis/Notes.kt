package app.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Notas de voz: "apunta comprar tornillos". Se guardan en el móvil y se ven en la app de Jarvis. */
object Notes {
    data class Note(val at: Long, val text: String)

    fun load(ctx: Context): MutableList<Note> {
        val out = ArrayList<Note>()
        try {
            val a = JSONArray(Prefs.get(ctx, "notes", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Note(o.optLong("t"), o.optString("x")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun save(ctx: Context, list: List<Note>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("t", it.at).put("x", it.text)) }
        Prefs.put(ctx, "notes", a.toString())
    }

    fun add(ctx: Context, text: String) {
        val l = load(ctx)
        l.add(Note(System.currentTimeMillis(), text))
        save(ctx, l)
    }

    fun removeLast(ctx: Context): Note? {
        val l = load(ctx)
        if (l.isEmpty()) return null
        val n = l.removeAt(l.size - 1)
        save(ctx, l)
        return n
    }

    fun clear(ctx: Context) = save(ctx, emptyList())

    fun removeAt(ctx: Context, index: Int) {
        val l = load(ctx)
        if (index in l.indices) { l.removeAt(index); save(ctx, l) }
    }

    fun readAloud(ctx: Context): String {
        val l = load(ctx)
        if (l.isEmpty()) return "No tienes notas."
        val last = l.takeLast(8)
        return (if (l.size > 8) "Tus últimas 8 notas. " else "Tienes ${l.size} ${if (l.size == 1) "nota" else "notas"}. ") +
            last.joinToString(". ") { it.text }
    }

    fun stamp(n: Note): String = SimpleDateFormat("d/M HH:mm", Locale("es", "ES")).format(Date(n.at))
}
