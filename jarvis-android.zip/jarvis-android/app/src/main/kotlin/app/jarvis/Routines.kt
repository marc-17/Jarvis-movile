package app.jarvis

import android.content.Context
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject

/**
 * Rutinas: una frase que ejecuta varias órdenes seguidas. Ej.: "buenas noches" = silencia + bloquea la pantalla.
 * Cada paso es una orden normal de Jarvis (cualquiera de las que entiende).
 */
object Routines {
    data class Routine(val phrase: String, val steps: List<String>)

    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context): MutableList<Routine> {
        val out = ArrayList<Routine>()
        try {
            val a = JSONArray(Prefs.get(ctx, "routines", "[]"))
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val st = o.getJSONArray("steps")
                out.add(Routine(o.getString("phrase"), (0 until st.length()).map { st.getString(it) }))
            }
        } catch (_: Exception) {
        }
        return out
    }

    fun save(ctx: Context, list: List<Routine>) {
        val a = JSONArray()
        list.forEach { r ->
            a.put(JSONObject().put("phrase", r.phrase).put("steps", JSONArray(r.steps)))
        }
        Prefs.put(ctx, "routines", a.toString())
    }

    fun add(ctx: Context, r: Routine) {
        val l = load(ctx).filter { Text.norm(it.phrase) != Text.norm(r.phrase) }.toMutableList()
        l.add(r)
        save(ctx, l)
    }

    fun remove(ctx: Context, phrase: String): Boolean {
        val l = load(ctx)
        val n = Text.norm(phrase)
        val keep = l.filter { Text.norm(it.phrase) != n }
        if (keep.size == l.size) return false
        save(ctx, keep)
        return true
    }

    /** Pasos separados por "luego", "después", "y luego", ";" o saltos de línea. */
    fun splitSteps(text: String): List<String> =
        text.split(Regex("\\s*(?:;|\\n|,? y luego |,? y después |,? y despues |,? luego |,? después |,? despues )\\s*", RegexOption.IGNORE_CASE))
            .map { it.trim().trim('.', ',') }
            .filter { it.isNotEmpty() }

    /** Busca una rutina por lo que dijiste: "buenas noches" o "ejecuta la rutina buenas noches". */
    fun find(ctx: Context, norm: String): Routine? {
        val c = norm.replace(Regex("^(ejecuta |lanza |activa |haz |pon )?(la )?(rutina )(de )?"), "").trim()
        return load(ctx).firstOrNull {
            val p = Text.norm(it.phrase)
            p == norm || p == c
        }
    }

    private val problem = Regex("^(No |Necesito|Activa|Ese |Esa |Falta|¿)")

    fun run(ctx: Context, r: Routine, reply: (String) -> Unit) {
        val app = ctx.applicationContext
        reply("Rutina ${r.phrase}")
        val problems = ArrayList<String>()
        fun step(i: Int) {
            if (i >= r.steps.size) {
                Conversation.clear()
                if (problems.isNotEmpty()) Speaker.say(app, "Ha habido un problema. " + problems.first())
                return
            }
            val s = r.steps[i]
            val wait = Regex("^(espera|aguarda|pausa de) (\\d+|un|una|dos|tres|cuatro|cinco|diez) ?(segundos?|s)?$").find(Text.norm(s))
            if (wait != null) {
                val n = Text.number(wait.groupValues[2]) ?: 1
                main.postDelayed({ step(i + 1) }, n * 1000L)
                return
            }
            CommandEngine.handle(app, s, false, { out ->
                if (problem.containsMatchIn(out)) problems.add(out)
            }, fromAi = true)
            Conversation.clear()
            main.postDelayed({ step(i + 1) }, 2500L)
        }
        main.postDelayed({ step(0) }, 1200L)
    }
}
