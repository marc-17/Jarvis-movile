package app.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract

/** Buscar y abrir apps por nombre, y llamadas. */
object Apps {
    const val METROLIST = "com.metrolist.music"
    const val NEWPIPE = "org.schabi.newpipe"

    // Nombre hablado (sin espacios, normalizado) -> posibles paquetes
    private val aliases = mapOf(
        "metrolist" to listOf(METROLIST, "com.metrolist.music.debug"),
        "newpipe" to listOf(NEWPIPE, "org.schabi.newpipe.debug"),
        "tiktok" to listOf("com.zhiliaoapp.musically", "com.ss.android.ugc.trill"),
        "whatsapp" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "wasap" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "guasap" to listOf("com.whatsapp", "com.whatsapp.w4b"),
        "whatsappbusiness" to listOf("com.whatsapp.w4b", "com.whatsapp"),
        "youtube" to listOf("com.google.android.youtube"),
        "instagram" to listOf("com.instagram.android"),
        "telegram" to listOf("org.telegram.messenger"),
        "discord" to listOf("com.discord"),
        "camara" to listOf("com.android.camera", "com.android.camera2", "com.google.android.GoogleCamera"),
        "ajustes" to listOf("com.android.settings"),
        "configuracion" to listOf("com.android.settings"),
        "chrome" to listOf("com.android.chrome"),
        "maps" to listOf("com.google.android.apps.maps"),
        "mapas" to listOf("com.google.android.apps.maps")
    )

    private fun isInstalled(ctx: Context, pkg: String) =
        ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    /** Devuelve el paquete de la app que mejor encaja con lo que dijiste, o null. */
    fun resolve(ctx: Context, spoken: String): String? {
        val key = Text.norm(spoken).replace(" ", "")
        if (key.isEmpty()) return null
        aliases[key]?.firstOrNull { isInstalled(ctx, it) }?.let { return it }
        if (isInstalled(ctx, spoken.trim())) return spoken.trim() // por si dices/pones el paquete exacto

        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(main, 0)
        var contains: String? = null
        for (ri in apps) {
            val label = Text.norm(ri.loadLabel(pm).toString()).replace(" ", "")
            val pkg = ri.activityInfo.packageName
            if (label == key) return pkg
            if (contains == null && label.isNotEmpty() && (label.contains(key) || key.contains(label))) contains = pkg
        }
        return contains
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(i); true } catch (_: Exception) { false }
    }

    // ---------- Llamadas ----------

    private fun has(ctx: Context, perm: String) =
        ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED

    /** Número a partir de lo dicho: "612 345 678" -> "612345678". null si no parece un número. */
    private fun asNumber(spoken: String): String? {
        val digits = spoken.filter { it.isDigit() }
        return if (digits.length >= 6 && spoken.none { it.isLetter() }) {
            (if (spoken.trim().startsWith("+")) "+" else "") + digits
        } else null
    }

    /** Número en formato internacional sin "+" (lo que pide wa.me). Si tiene 9 cifras, asume España (34). */
    fun intl(number: String): String {
        var d = number.filter { it.isDigit() }
        if (d.startsWith("00")) d = d.substring(2)
        return if (d.length == 9) "34$d" else d
    }

    data class Contact(val name: String, val number: String)

    /** "mi madre" -> "mama", "a mi padre" -> "papa", quita "mi", "a", "el"... */
    fun normWho(spoken: String): String {
        var t = Text.norm(spoken).replace(Regex("^((a|al|la|el|mi|mis|a mi|a la|a el) )+"), "")
        t = t.split(" ").joinToString(" ") { when (it) { "madre" -> "mama"; "padre" -> "papa"; else -> it } }
        return t.ifEmpty { Text.norm(spoken) }
    }

    /** Todos los contactos que encajan con lo dicho (uno por nombre, con su móvil si lo tiene). */
    fun findContacts(ctx: Context, spoken: String): List<Contact> {
        if (!has(ctx, Manifest.permission.READ_CONTACTS)) return emptyList()
        val target = normWho(spoken)
        if (target.isEmpty()) return emptyList()
        val best = LinkedHashMap<String, Pair<Contact, Boolean>>() // nombre -> (contacto, esMovil)
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.CommonDataKinds.Phone.TYPE
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(0) ?: continue
                val number = c.getString(1) ?: continue
                val mobile = c.getInt(2) == ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                val prev = best[name]
                if (prev == null || (mobile && !prev.second)) best[name] = Contact(name, number) to mobile
            }
        }
        val all = best.values.map { it.first }
        val exact = all.filter { Text.norm(it.name) == target }
        if (exact.isNotEmpty()) return exact
        val tokens = target.split(" ")
        return all.filter {
            val n = Text.norm(it.name)
            n.isNotEmpty() && (n.contains(target) || (n.length >= 3 && target.contains(n)) || tokens.all { t -> n.split(" ").contains(t) })
        }
    }

    fun findContact(ctx: Context, spoken: String): Pair<String, String>? =
        findContacts(ctx, spoken).firstOrNull()?.let { it.name to it.number }

    /** Llama a un número o a un contacto. Devuelve el texto que Jarvis debe decir. */
    fun call(ctx: Context, spoken: String): String {
        val number: String
        val label: String
        val direct = asNumber(spoken)
        if (direct != null) {
            number = direct
            label = "ese número"
        } else {
            if (!has(ctx, Manifest.permission.READ_CONTACTS)) return "Necesito permiso para leer los contactos."
            val c = findContact(ctx, spoken) ?: return "No encuentro a $spoken en tus contactos."
            number = c.second
            label = c.first
        }
        val uri = Uri.parse("tel:" + Uri.encode(number))
        val action = if (has(ctx, Manifest.permission.CALL_PHONE)) Intent.ACTION_CALL else Intent.ACTION_DIAL
        return try {
            ctx.startActivity(Intent(action, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            if (action == Intent.ACTION_CALL) "Llamando a $label" else "Te dejo marcado el número de $label; falta el permiso de llamadas."
        } catch (e: Exception) {
            "No he podido llamar."
        }
    }
}
