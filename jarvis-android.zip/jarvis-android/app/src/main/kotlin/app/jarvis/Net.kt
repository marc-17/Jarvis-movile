package app.jarvis

import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL

/** Red mínima sin librerías. Todo lo de red va en un hilo aparte y devuelve el resultado al hilo principal. */
object Net {
    private val main = Handler(Looper.getMainLooper())

    class HttpException(val code: Int, val body: String) : Exception("HTTP $code")

    private fun read(c: HttpURLConnection): String {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw HttpException(code, text)
        return text
    }

    fun get(url: String, timeoutMs: Int = 10000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", "Jarvis/1.0")
            return read(c)
        } finally {
            c.disconnect()
        }
    }

    fun postJson(url: String, body: String, headers: Map<String, String> = emptyMap(), timeoutMs: Int = 15000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            return read(c)
        } finally {
            c.disconnect()
        }
    }

    /** Ejecuta [work] en un hilo y llama a [done] en el principal con (resultado, error). */
    fun <T> background(work: () -> T, done: (T?, Throwable?) -> Unit) {
        Thread {
            var res: T? = null
            var err: Throwable? = null
            try { res = work() } catch (t: Throwable) { err = t }
            main.post { done(res, err) }
        }.start()
    }
}
