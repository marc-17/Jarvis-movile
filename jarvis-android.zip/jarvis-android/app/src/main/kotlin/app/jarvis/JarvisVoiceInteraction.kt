package app.jarvis

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService

/**
 * Estas tres clases son lo que hace que Jarvis salga en
 * Ajustes > Apps > Apps predeterminadas > Asistente digital.
 * Al invocar al asistente (mantener botón de inicio / gesto), se abre la ventana de escucha.
 */
class JarvisVoiceInteractionService : VoiceInteractionService()

class JarvisVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = JarvisSession(this)
}

class JarvisSession(private val ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(ctx, ListenActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            startAssistantActivity(i)
        } catch (e: Exception) {
            try { ctx.startActivity(i) } catch (_: Exception) {}
        }
        hide()
    }
}
