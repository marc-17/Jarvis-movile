package app.jarvis

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.provider.Settings

/** No molestar. Necesita que actives el permiso «Acceso a No molestar» para Jarvis (botón en la app). */
object Dnd {
    fun granted(ctx: Context) =
        ctx.getSystemService(NotificationManager::class.java).isNotificationPolicyAccessGranted

    /** [alarmsOnly] = solo suenan las alarmas (ideal para dormir). Devuelve null si todo fue bien, o lo que hay que decir. */
    fun set(ctx: Context, on: Boolean, alarmsOnly: Boolean = false): String? {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        if (!nm.isNotificationPolicyAccessGranted) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
            return "Necesito el permiso de No molestar. Te abro los ajustes: activa Jarvis y repítemelo."
        }
        nm.setInterruptionFilter(
            if (!on) NotificationManager.INTERRUPTION_FILTER_ALL
            else if (alarmsOnly) NotificationManager.INTERRUPTION_FILTER_ALARMS
            else NotificationManager.INTERRUPTION_FILTER_PRIORITY
        )
        return null
    }
}
