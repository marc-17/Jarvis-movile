package app.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Pantalla de ajustes de Jarvis: permisos, activar servicios y tus comandos personalizados. */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var customBox: LinearLayout
    private lateinit var modeSwitch: Switch
    private lateinit var routinesBox: LinearLayout
    private lateinit var notesBox: LinearLayout
    private lateinit var remindersBox: LinearLayout
    private var updating = false

    private val perms: Array<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.ANSWER_PHONE_CALLS)
        add(Manifest.permission.SEND_SMS)
        add(Manifest.permission.CAMERA)
        add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 15f, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(Color.parseColor("#111827"))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun open(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Este móvil no abre esa pantalla de ajustes.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(40))
        }
        col.addView(text("Jarvis", 30f, true))
        col.addView(text("Tu asistente de voz. Mantén pulsado el botón de encendido para invocarlo (cuando lo elijas como asistente)."))

        statusView = text("", 15f)
        col.addView(statusView)

        col.addView(button("1. Dar permisos (micrófono, llamadas, contactos)") {
            requestPermissions(perms, 1)
        })
        col.addView(button("2. Activar accesibilidad de Jarvis") {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("3. Activar acceso a notificaciones") {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("4. Permitir mostrarse sobre otras apps") {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("5. Elegir Jarvis como asistente") {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                open(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
        })
        col.addView(text("Si Android no te deja activar la accesibilidad o las notificaciones (ajustes restringidos): abre la ficha de Jarvis, toca ⋮ arriba a la derecha y elige «Permitir ajustes restringidos». Luego repite el paso.", 13f))
        col.addView(button("Abrir ficha de la app (ajustes restringidos)") {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(button("Probar Jarvis ahora") {
            startActivity(Intent(this, ListenActivity::class.java))
        })

        // ---- IA y ajustes ----
        col.addView(text("Inteligencia artificial (Gemini)", 20f, true))
        col.addView(text("Es el plan B cuando Jarvis no entiende una frase y lo que permite charlar y hacer preguntas. Saca una clave gratis en aistudio.google.com/apikey y pégala aquí. Se guarda solo en este móvil.", 13f))
        val keyBox = EditText(this).apply {
            hint = "Clave de Gemini (empieza por AIza…)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(Prefs.geminiKey(this@MainActivity))
        }
        val modelBox = EditText(this).apply {
            hint = "Modelo (vacío = ${Gemini.DEFAULT_MODEL})"
            setText(Prefs.get(this@MainActivity, "gemini_model"))
        }
        val cityBox = EditText(this).apply {
            hint = "Tu ciudad para el tiempo (opcional)"
            setText(Prefs.city(this@MainActivity))
        }
        col.addView(keyBox)
        col.addView(modelBox)
        col.addView(cityBox)
        col.addView(button("Guardar ajustes de IA") {
            Prefs.put(this, "gemini_key", keyBox.text.toString().trim())
            Prefs.put(this, "gemini_model", modelBox.text.toString().trim())
            Prefs.put(this, "city", cityBox.text.toString().trim())
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show()
            refresh()
        })
        col.addView(button("Probar Gemini") {
            Prefs.put(this, "gemini_key", keyBox.text.toString().trim())
            Prefs.put(this, "gemini_model", modelBox.text.toString().trim())
            if (!Gemini.configured(this)) {
                Toast.makeText(this, "Pega primero la clave", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Probando…", Toast.LENGTH_SHORT).show()
                val app = applicationContext
                Net.background({
                    Gemini.generate(app, "Responde en español con una frase corta.", listOf("user" to "Di: hola, soy Jarvis y funciono."), false)
                }) { res, err ->
                    val msg = if (err != null) "❌ " + Gemini.explain(err) else "✅ " + (res ?: "")
                    AlertDialog.Builder(this).setTitle("Gemini").setMessage(msg).setPositiveButton("Vale", null).show()
                }
            }
        })
        col.addView(Switch(this).apply {
            text = "Pedir confirmación («¿Lo envío?») antes de mandar mensajes"
            isChecked = Prefs.confirmSend(this@MainActivity)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, on -> Prefs.putBool(this@MainActivity, "confirm_send", on) }
        })

        // ---- Voz y avisos ----
        col.addView(text("Voz y avisos", 20f, true))
        val rateNames = arrayOf("Lenta", "Normal", "Rápida", "Muy rápida")
        val rateValues = arrayOf("0.8", "1.0", "1.25", "1.5")
        col.addView(text("Velocidad de la voz", 14f))
        col.addView(Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, rateNames)
            val cur = Prefs.get(this@MainActivity, "tts_rate", "1.0")
            setSelection(rateValues.indexOf(cur).coerceAtLeast(0))
            onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: android.widget.AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    Prefs.put(this@MainActivity, "tts_rate", rateValues[pos])
                }
                override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
            }
        })
        col.addView(button("Elegir voz (las «network» o de más calidad suenan más naturales)") {
            Speaker.withVoices(this) { voices ->
                if (voices.isEmpty()) {
                    Toast.makeText(this, "No hay voces en español. Instálalas en Ajustes > Salida de texto a voz.", Toast.LENGTH_LONG).show()
                } else {
                    val names = voices.map { v -> v.name + " · calidad " + v.quality + (if (v.isNetworkConnectionRequired) " · online" else "") }
                    AlertDialog.Builder(this).setTitle("Voz de Jarvis")
                        .setItems(names.toTypedArray()) { _, i ->
                            Prefs.put(this, "tts_voice", voices[i].name)
                            Speaker.say(this, "Hola, soy Jarvis. ¿Qué tal suena mi voz?")
                        }
                        .setNeutralButton("Automática") { _, _ -> Prefs.put(this, "tts_voice", "") }
                        .setNegativeButton("Cancelar", null).show()
                }
            }
        })
        col.addView(button("Probar la voz") { Speaker.say(this, "Hola, soy Jarvis. Así suena mi voz con esta velocidad.") })
        col.addView(Switch(this).apply {
            text = "Pitido y vibración cuando te escucha"
            isChecked = Prefs.getBool(this@MainActivity, "feedback", true)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, on -> Prefs.putBool(this@MainActivity, "feedback", on) }
        })
        col.addView(Switch(this).apply {
            text = "Decir en voz alta quién llama"
            isChecked = Prefs.getBool(this@MainActivity, "announce_calls", true)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, on -> Prefs.putBool(this@MainActivity, "announce_calls", on) }
        })
        col.addView(button("Permiso de No molestar (para «me voy a dormir»)") {
            open(Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))
        })

        modeSwitch = Switch(this).apply {
            text = "Modo pantalla rota (escucha siempre, di «Jarvis…»)"
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, on ->
                if (updating) return@setOnCheckedChangeListener
                if (on) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(perms, 1)
                        refresh()
                    } else {
                        startForegroundService(Intent(this@MainActivity, ContinuousService::class.java))
                    }
                } else {
                    stopService(Intent(this@MainActivity, ContinuousService::class.java))
                }
            }
        }
        col.addView(modeSwitch)

        col.addView(text("Tus comandos", 20f, true))
        customBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(customBox)
        col.addView(button("Añadir comando") { addDialog() })

        col.addView(text("Rutinas", 20f, true))
        col.addView(text("Una frase que ejecuta varias órdenes seguidas. Ej.: «buenas noches» = silencia · espera 2 segundos · bloquea la pantalla.", 13f))
        routinesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(routinesBox)
        col.addView(button("Añadir rutina") { routineDialog() })

        col.addView(text("Recordatorios", 20f, true))
        remindersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(remindersBox)

        col.addView(text("Notas de voz", 20f, true))
        notesBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(notesBox)

        col.addView(text("Qué puedes decirle", 20f, true))
        col.addView(text(
            "Empieza por «Jarvis» en modo pantalla rota; al invocarlo con el botón no hace falta.\n\n" +
                "• Abre WhatsApp / Metrolist / TikTok / cualquier app\n" +
                "• Pon Ozuna (busca en Metrolist y pulsa el primer resultado)\n" +
                "• Pausa · siguiente · anterior · continúa\n" +
                "• Llama a mamá · llama al 612345678 · contesta · cuelga\n" +
                "• Envía un whatsapp a mamá → «¿Qué le pongo?» → «ya voy» → «¿Lo envío?» → «sí»\n" +
                "• Lee mis mensajes · dile que ahora voy · responde a Marcos que sí\n" +
                "• Qué tiempo hace (en Madrid / mañana) · cuánto es 25 por 4\n" +
                "• Recuérdame mañana a las 9 llamar a Marcos · qué recordatorios tengo\n" +
                "• Apunta comprar tornillos · lee mis notas\n" +
                "• Siguiente vídeo · vídeo anterior · dale like · pausa (en TikTok)\n" +
                "• Crea una rutina buenas noches · (y la dices cuando quieras)\n" +
                "• Qué hay en pantalla · resume la pantalla (Gemini la resume) · lee la pantalla entera\n" +
                "• Resúmeme mis mensajes · resúmeme las notificaciones\n" +
                "• Traduce al inglés dónde está la estación (lo dice en inglés) · cómo se dice hola en francés\n" +
                "• Qué es esto · lee este cartel (hace una foto y Gemini la mira; con Jarvis a la vista)\n" +
                "• Contesta a Marcos diciendo que no puedo pero amable (Gemini lo redacta) · redacta un mensaje a mamá para decirle que llego tarde\n" +
                "• Dicta (escribe lo que digas en el campo abierto; «fin del dictado» para terminar)\n" +
                "• Me voy a dormir (No molestar + alarma + apaga la escucha) · buenos días\n" +
                "• Quién llama · contesta · cuelga (y te dice quién llama al sonar)\n" +
                "• Cualquier otra cosa: si hay clave de Gemini, te contesta y charla\n" +
                "• Busca vídeos de X en NewPipe\n" +
                "• Accesibilidad (lee cada pantalla nueva) · qué botones hay · pulsa el 2\n" +
                "• Lee la pantalla · baja · sube · atrás · inicio · recientes\n" +
                "• Pulsa Aceptar · escribe hola · intro\n" +
                "• Lee mis notificaciones · repite\n" +
                "• Pon una alarma a las 7 y media · temporizador de 5 minutos\n" +
                "• Llévame a la estación del Norte · linterna · volumen\n" +
                "• Qué hora es · cuánta batería queda · cuéntame un chiste\n" +
                "• Modo pantalla rota · desactiva modo pantalla rota",
            14f
        ))

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val granted = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val a11y = JarvisAccessibilityService.instance != null
        val notif = JarvisNotificationService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        val assistant = try {
            Settings.Secure.getString(contentResolver, "assistant")?.contains(packageName) == true
        } catch (e: Exception) {
            false
        }
        fun line(ok: Boolean, label: String) = (if (ok) "✅ " else "❌ ") + label
        statusView.text = listOf(
            line(granted, "Permisos"),
            line(a11y, "Accesibilidad"),
            line(notif, "Notificaciones"),
            line(overlay, "Sobre otras apps"),
            line(assistant, "Jarvis es tu asistente"),
            line(Gemini.configured(this), "IA Gemini (opcional)")
        ).joinToString("\n")

        updating = true
        modeSwitch.isChecked = ContinuousService.running
        updating = false

        renderCustom()
        renderRoutines()
        renderReminders()
        renderNotes()
    }

    private fun renderRoutines() {
        routinesBox.removeAllViews()
        val list = Routines.load(this)
        if (list.isEmpty()) { routinesBox.addView(text("Aún no tienes ninguna.", 14f)); return }
        list.forEach { r ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(
                text("«${r.phrase}» → ${r.steps.joinToString(" · ")}", 14f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(button("Borrar") { Routines.remove(this, r.phrase); renderRoutines() })
            routinesBox.addView(row)
        }
    }

    private fun renderReminders() {
        remindersBox.removeAllViews()
        val list = Reminders.load(this).sortedBy { it.at }
        if (list.isEmpty()) { remindersBox.addView(text("Ninguno. Di: recuérdame mañana a las 9 llamar a Marcos.", 14f)); return }
        list.forEach { r ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(
                text("${Reminders.whenText(r.at)}: ${r.text}", 14f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(button("Borrar") { Reminders.remove(this, r.id); renderReminders() })
            remindersBox.addView(row)
        }
    }

    private fun renderNotes() {
        notesBox.removeAllViews()
        val list = Notes.load(this)
        if (list.isEmpty()) { notesBox.addView(text("Ninguna. Di: apunta comprar tornillos.", 14f)); return }
        list.forEachIndexed { idx, n ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(
                text("${Notes.stamp(n)} — ${n.text}", 14f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(button("Borrar") { Notes.removeAt(this, idx); renderNotes() })
            notesBox.addView(row)
        }
    }

    private fun routineDialog() {
        val phrase = EditText(this).apply { hint = "Lo que dirás (ej: buenas noches)" }
        val steps = EditText(this).apply {
            hint = "Pasos, uno por línea (ej:\nsilencia\nespera 2 segundos\nbloquea la pantalla)"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(phrase)
            addView(steps)
        }
        AlertDialog.Builder(this)
            .setTitle("Nueva rutina")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val p = phrase.text.toString().trim()
                val st = Routines.splitSteps(steps.text.toString())
                if (p.isNotEmpty() && st.isNotEmpty()) {
                    Routines.add(this, Routines.Routine(p, st))
                    renderRoutines()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun typeName(code: String) = when (code) {
        Custom.APP -> "abrir app"
        Custom.URL -> "abrir enlace"
        Custom.CALL -> "llamar"
        else -> "decir"
    }

    private fun renderCustom() {
        customBox.removeAllViews()
        val list = CustomCommands.load(this)
        if (list.isEmpty()) {
            customBox.addView(text("Aún no tienes ninguno. Ej.: «mi lista» → abrir Metrolist.", 14f))
            return
        }
        list.forEachIndexed { idx, c ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(
                text("«${c.phrase}» → ${typeName(c.type)}: ${c.value}", 14f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(button("Borrar") {
                val l = CustomCommands.load(this)
                if (idx < l.size) l.removeAt(idx)
                CustomCommands.save(this, l)
                renderCustom()
            })
            customBox.addView(row)
        }
    }

    private fun addDialog() {
        val types = arrayOf("Abrir app (nombre)", "Abrir enlace", "Llamar (nombre o número)", "Decir un texto")
        val codes = arrayOf(Custom.APP, Custom.URL, Custom.CALL, Custom.SAY)
        val phrase = EditText(this).apply { hint = "Lo que dirás (ej: mi lista)" }
        val value = EditText(this).apply { hint = "Valor (ej: Metrolist, https://..., mamá)" }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, types)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(phrase)
            addView(spinner)
            addView(value)
        }
        AlertDialog.Builder(this)
            .setTitle("Nuevo comando")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val p = phrase.text.toString().trim()
                val v = value.text.toString().trim()
                if (p.isNotEmpty() && v.isNotEmpty()) {
                    val l = CustomCommands.load(this)
                    l.add(Custom(p, codes[spinner.selectedItemPosition], v))
                    CustomCommands.save(this, l)
                    renderCustom()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
