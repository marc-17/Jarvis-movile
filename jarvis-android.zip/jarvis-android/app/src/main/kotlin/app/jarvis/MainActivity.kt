package app.jarvis

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** Pantalla de ajustes de Jarvis: permisos, activar servicios y tus comandos personalizados. */
class MainActivity : Activity() {

    private lateinit var statusView: TextView
    private lateinit var customBox: LinearLayout
    private lateinit var modeSwitch: Switch
    private var updating = false

    private val perms: Array<String> = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        add(Manifest.permission.CALL_PHONE)
        add(Manifest.permission.READ_CONTACTS)
        add(Manifest.permission.ANSWER_PHONE_CALLS)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }.toTypedArray()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun text(s: String, size: Float = 15f, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        textSize = size
        setTextColor(Color.parseColor("#111827"))
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun button(label: String, onClick: () -> Unit): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun open(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Este móvil no abre esa pantalla de ajustes.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(40))
        }
        col.addView(text("Jarvis", 30f, true))
        col.addView(text("Tu asistente de voz. Mantén pulsado el botón de encendido para invocarlo (cuando lo elijas como asistente)."))

        statusView = text("", 15f)
        col.addView(statusView)

        col.addView(button("1. Dar permisos (micrófono, llamadas, contactos)") {
            requestPermissions(perms, 1)
        })
        col.addView(button("2. Activar accesibilidad de Jarvis") {
            open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(button("3. Activar acceso a notificaciones") {
            open(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        })
        col.addView(button("4. Permitir mostrarse sobre otras apps") {
            open(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(button("5. Elegir Jarvis como asistente") {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                open(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
        })
        col.addView(text("Si Android no te deja activar la accesibilidad o las notificaciones (ajustes restringidos): abre la ficha de Jarvis, toca ⋮ arriba a la derecha y elige «Permitir ajustes restringidos». Luego repite el paso.", 13f))
        col.addView(button("Abrir ficha de la app (ajustes restringidos)") {
            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
        col.addView(button("Probar Jarvis ahora") {
            startActivity(Intent(this, ListenActivity::class.java))
        })

        modeSwitch = Switch(this).apply {
            text = "Modo pantalla rota (escucha siempre, di «Jarvis…»)"
            setPadding(0, dp(16), 0, dp(16))
            setOnCheckedChangeListener { _, on ->
                if (updating) return@setOnCheckedChangeListener
                if (on) {
                    if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(perms, 1)
                        refresh()
                    } else {
                        startForegroundService(Intent(this@MainActivity, ContinuousService::class.java))
                    }
                } else {
                    stopService(Intent(this@MainActivity, ContinuousService::class.java))
                }
            }
        }
        col.addView(modeSwitch)

        col.addView(text("Tus comandos", 20f, true))
        customBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(customBox)
        col.addView(button("Añadir comando") { addDialog() })

        col.addView(text("Qué puedes decirle", 20f, true))
        col.addView(text(
            "Empieza por «Jarvis» en modo pantalla rota; al invocarlo con el botón no hace falta.\n\n" +
                "• Abre WhatsApp / Metrolist / TikTok / cualquier app\n" +
                "• Pon Ozuna (busca en Metrolist y pulsa el primer resultado)\n" +
                "• Pausa · siguiente · anterior · continúa\n" +
                "• Llama a mamá · llama al 612345678 · contesta · cuelga\n" +
                "• Manda un whatsapp a Marcos diciendo ya voy → luego «enviar»\n" +
                "• Busca vídeos de X en NewPipe\n" +
                "• Accesibilidad (lee cada pantalla nueva) · qué botones hay · pulsa el 2\n" +
                "• Lee la pantalla · baja · sube · atrás · inicio · recientes\n" +
                "• Pulsa Aceptar · escribe hola · intro\n" +
                "• Lee mis notificaciones · repite\n" +
                "• Pon una alarma a las 7 y media · temporizador de 5 minutos\n" +
                "• Llévame a la estación del Norte · linterna · volumen\n" +
                "• Qué hora es · cuánta batería queda · cuéntame un chiste\n" +
                "• Modo pantalla rota · desactiva modo pantalla rota",
            14f
        ))

        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    private fun refresh() {
        val granted = perms.all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val a11y = JarvisAccessibilityService.instance != null
        val notif = JarvisNotificationService.instance != null
        val overlay = Settings.canDrawOverlays(this)
        val assistant = try {
            Settings.Secure.getString(contentResolver, "assistant")?.contains(packageName) == true
        } catch (e: Exception) {
            false
        }
        fun line(ok: Boolean, label: String) = (if (ok) "✅ " else "❌ ") + label
        statusView.text = listOf(
            line(granted, "Permisos"),
            line(a11y, "Accesibilidad"),
            line(notif, "Notificaciones"),
            line(overlay, "Sobre otras apps"),
            line(assistant, "Jarvis es tu asistente")
        ).joinToString("\n")

        updating = true
        modeSwitch.isChecked = ContinuousService.running
        updating = false

        renderCustom()
    }

    private fun typeName(code: String) = when (code) {
        Custom.APP -> "abrir app"
        Custom.URL -> "abrir enlace"
        Custom.CALL -> "llamar"
        else -> "decir"
    }

    private fun renderCustom() {
        customBox.removeAllViews()
        val list = CustomCommands.load(this)
        if (list.isEmpty()) {
            customBox.addView(text("Aún no tienes ninguno. Ej.: «mi lista» → abrir Metrolist.", 14f))
            return
        }
        list.forEachIndexed { idx, c ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(
                text("«${c.phrase}» → ${typeName(c.type)}: ${c.value}", 14f),
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(button("Borrar") {
                val l = CustomCommands.load(this)
                if (idx < l.size) l.removeAt(idx)
                CustomCommands.save(this, l)
                renderCustom()
            })
            customBox.addView(row)
        }
    }

    private fun addDialog() {
        val types = arrayOf("Abrir app (nombre)", "Abrir enlace", "Llamar (nombre o número)", "Decir un texto")
        val codes = arrayOf(Custom.APP, Custom.URL, Custom.CALL, Custom.SAY)
        val phrase = EditText(this).apply { hint = "Lo que dirás (ej: mi lista)" }
        val value = EditText(this).apply { hint = "Valor (ej: Metrolist, https://..., mamá)" }
        val spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, types)
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), 0)
            addView(phrase)
            addView(spinner)
            addView(value)
        }
        AlertDialog.Builder(this)
            .setTitle("Nuevo comando")
            .setView(box)
            .setPositiveButton("Guardar") { _, _ ->
                val p = phrase.text.toString().trim()
                val v = value.text.toString().trim()
                if (p.isNotEmpty() && v.isNotEmpty()) {
                    val l = CustomCommands.load(this)
                    l.add(Custom(p, codes[spinner.selectedItemPosition], v))
                    CustomCommands.save(this, l)
                    renderCustom()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
}
