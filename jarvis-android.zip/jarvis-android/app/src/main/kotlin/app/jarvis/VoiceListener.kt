package app.jarvis

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Envuelve SpeechRecognizer (el reconocedor de voz que traiga el móvil, offline si tiene el paquete de español).
 * loop = false: escucha una frase y avisa. loop = true: escucha sin parar (modo pantalla rota).
 * Todo debe llamarse desde el hilo principal.
 */
class VoiceListener(
    private val ctx: Context,
    private val loop: Boolean,
    private val onText: (String) -> Unit,
    private val onError: (Int) -> Unit = {}
) {
    private val main = Handler(Looper.getMainLooper())
    private var rec: SpeechRecognizer? = null
    private var active = false
    private var paused = false
    private var preferOffline = true

    fun start() {
        active = true
        paused = false
        begin()
    }

    fun stop() {
        active = false
        destroy()
    }

    /** Silencia el micro mientras Jarvis habla para que no se oiga a sí mismo. */
    fun pause() {
        paused = true
        destroy()
    }

    fun resume() {
        paused = false
        if (active && loop) main.postDelayed({ begin() }, 400)
    }

    private fun destroy() {
        rec?.let {
            try { it.cancel() } catch (_: Exception) {}
            try { it.destroy() } catch (_: Exception) {}
        }
        rec = null
    }

    private fun restart(delayMs: Long) {
        if (active && loop && !paused) main.postDelayed({ begin() }, delayMs)
    }

    /**
     * Al elegir Jarvis como asistente, Android puede dejar el reconocedor de Jarvis (que no reconoce nada) como
     * predeterminado. Por eso se busca a mano uno de otra app, preferiblemente el de Google.
     */
    private fun pickRecognizer(): ComponentName? {
        val found = ctx.packageManager
            .queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
            .map { it.serviceInfo }
            .filter { it.packageName != ctx.packageName }
        val google = found.firstOrNull { it.packageName == "com.google.android.googlequicksearchbox" }
        val s = google ?: found.firstOrNull() ?: return null
        return ComponentName(s.packageName, s.name)
    }

    private fun begin() {
        if (!active || paused) return
        val component = pickRecognizer()
        if (component == null && !SpeechRecognizer.isRecognitionAvailable(ctx)) {
            onError(SpeechRecognizer.ERROR_CLIENT)
            return
        }
        destroy()
        val r = if (component != null) SpeechRecognizer.createSpeechRecognizer(ctx, component)
        else SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onText(text)
                else if (!loop) this@VoiceListener.onError(SpeechRecognizer.ERROR_NO_MATCH)
                restart(300)
            }

            override fun onError(error: Int) {
                if (!active) return
                // 12 = idioma no soportado, 13 = idioma no disponible (sin paquete offline): probamos online
                if ((error == 12 || error == 13) && preferOffline) {
                    preferOffline = false
                    restart(100)
                    if (!loop) begin()
                    return
                }
                if (loop) {
                    when (error) {
                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { active = false; this@VoiceListener.onError(error) }
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> restart(1200)
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(250)
                        else -> restart(1500)
                    }
                } else {
                    this@VoiceListener.onError(error)
                }
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES")
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        r.startListening(i)
    }
}
