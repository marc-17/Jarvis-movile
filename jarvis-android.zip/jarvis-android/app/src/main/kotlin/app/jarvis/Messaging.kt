package app.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager

/**
 * Mandar mensajes por voz, con conversación:
 *   "envía un whatsapp a mamá" -> "¿Qué le pongo?" -> "ya voy" -> "Le digo a Mamá: ya voy. ¿Lo envío?" -> "sí" -> enviado.
 */
object Messaging {
    private val main = Handler(Looper.getMainLooper())

    private val ordinals = mapOf(
        "primero" to 0, "primer" to 0, "uno" to 0, "1" to 0, "segundo" to 1, "dos" to 1, "2" to 1,
        "tercero" to 2, "tres" to 2, "3" to 2, "cuarto" to 3, "cuatro" to 3, "4" to 3
    )

    /** [msg] null o vacío = hay que preguntarlo. [channel] = "whatsapp" o "sms". */
    fun start(ctx: Context, channel: String, who: String, msg: String?, reply: (String) -> Unit) {
        val spokenDigits = who.filter { it.isDigit() }
        if (spokenDigits.length >= 6 && who.none { it.isLetter() }) {
            gotContact(ctx, channel, who, spokenDigits, msg, reply)
            return
        }
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            reply("Necesito permiso para leer los contactos. Abre la app de Jarvis y dáselo.")
            return
        }
        val found = Apps.findContacts(ctx, who)
        when {
            found.isEmpty() -> reply("No encuentro a $who en tus contactos.")
            found.size == 1 -> gotContact(ctx, channel, found[0].name, found[0].number, msg, reply)
            else -> {
                val shown = found.take(4)
                Conversation.ask { c, ans, r ->
                    val n = Text.norm(ans)
                    val pick = shown.firstOrNull { val x = Text.norm(it.name); x.contains(n) || (n.length > 2 && n.contains(x)) }
                        ?: n.split(" ").mapNotNull { ordinals[it] }.firstOrNull()?.let { shown.getOrNull(it) }
                    if (pick == null) r("No te he entendido, lo dejo.")
                    else gotContact(c, channel, pick.name, pick.number, msg, r)
                }
                reply("Tengo varios: " + shown.joinToString(", o ") { it.name } + ". ¿Cuál?")
            }
        }
    }

    private fun gotContact(ctx: Context, channel: String, name: String, number: String, msg: String?, reply: (String) -> Unit) {
        if (msg.isNullOrBlank()) {
            Conversation.ask { c, ans, r -> compose(c, channel, name, number, ans.trim(), r) }
            reply("¿Qué le pongo a $name?")
        } else {
            compose(ctx, channel, name, number, msg.trim(), reply)
        }
    }

    private fun compose(ctx: Context, channel: String, name: String, number: String, text: String, reply: (String) -> Unit) {
        if (text.isBlank()) { reply("No he oído el mensaje. Lo dejo."); return }
        if (!Prefs.confirmSend(ctx)) { send(ctx, channel, name, number, text, reply); return }
        confirm(
            "Le digo a $name: $text. ¿Lo envío?", reply,
            onChange = { c, newText, r -> compose(c, channel, name, number, newText, r) },
            onYes = { r -> send(ctx, channel, name, number, text, r) }
        )
    }

    /** Pregunta "¿Lo envío?" y espera sí / no / un texto nuevo. */
    fun confirm(
        prompt: String,
        reply: (String) -> Unit,
        onChange: (Context, String, (String) -> Unit) -> Unit,
        onYes: ((String) -> Unit) -> Unit,
        tries: Int = 0
    ) {
        Conversation.ask { c, ans, r ->
            val n = Text.norm(ans)
            when {
                Conversation.isYes(n) || Conversation.leansYes(n) -> onYes(r)
                Conversation.isNo(n) || Conversation.leansNo(n) -> r("Vale, no lo envío.")
                n.split(" ").size > 3 ->
                    onChange(c, ans.trim().replace(Regex("^(cambia|cambialo|pon|mejor|di|dile) (que )?", RegexOption.IGNORE_CASE), ""), r)
                tries < 1 -> confirm("¿Lo envío? Di sí o no.", r, onChange, onYes, tries + 1)
                else -> r("Vale, lo dejo.")
            }
        }
        reply(prompt)
    }

    fun send(ctx: Context, channel: String, name: String, number: String, text: String, reply: (String) -> Unit) {
        if (channel == "sms") sendSms(ctx, name, number, text, reply) else sendWhatsApp(ctx, name, number, text, reply)
    }

    private fun sendSms(ctx: Context, name: String, number: String, text: String, reply: (String) -> Unit) {
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                @Suppress("DEPRECATION")
                val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else SmsManager.getDefault()
                val parts = sm.divideMessage(text)
                if (parts.size > 1) sm.sendMultipartTextMessage(number, null, parts, null, null)
                else sm.sendTextMessage(number, null, text, null, null)
                reply("SMS enviado a $name")
            } catch (e: Exception) {
                reply("No he podido enviar el SMS.")
            }
            return
        }
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", text)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            reply("Te lo dejo escrito para $name. Para que lo envíe yo, dame el permiso de SMS en la app de Jarvis.")
        } catch (e: Exception) {
            reply("No he podido abrir la app de mensajes.")
        }
    }

    private fun sendWhatsApp(ctx: Context, name: String, number: String, text: String, reply: (String) -> Unit) {
        val pkg = Apps.resolve(ctx, "whatsapp")
        if (pkg == null) { reply("No encuentro WhatsApp instalado."); return }
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + Apps.intl(number) + "?text=" + Uri.encode(text)))
            .setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            reply("No he podido abrir WhatsApp."); return
        }
        if (JarvisAccessibilityService.instance == null) {
            reply("Te lo he dejado escrito en WhatsApp para $name. Dale tú a enviar, o activa la accesibilidad de Jarvis para que lo haga yo.")
            return
        }
        reply("Enviando a $name")
        pressSend(ctx.applicationContext, name, 0)
    }

    /** Espera a que el chat esté abierto con el texto puesto y pulsa enviar (reintenta unos segundos). */
    private fun pressSend(ctx: Context, name: String, attempt: Int) {
        main.postDelayed({
            val s = JarvisAccessibilityService.instance
            if (s != null && s.clickSend()) return@postDelayed
            if (attempt < 14) pressSend(ctx, name, attempt + 1)
            else Speaker.say(ctx, "No he podido pulsar enviar. El mensaje para $name está escrito en WhatsApp.")
        }, if (attempt == 0) 2200L else 900L)
    }
}
