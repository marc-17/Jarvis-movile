package app.jarvis

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import org.json.JSONObject
import java.net.URLEncoder

/** El tiempo con Open-Meteo (gratis, sin clave). */
object Weather {

    private fun describe(code: Int): String = when (code) {
        0 -> "cielo despejado"
        1 -> "casi despejado"
        2 -> "parcialmente nublado"
        3 -> "nublado"
        45, 48 -> "niebla"
        51, 53, 55 -> "llovizna"
        56, 57 -> "llovizna helada"
        61 -> "lluvia débil"
        63 -> "lluvia"
        65 -> "lluvia fuerte"
        66, 67 -> "lluvia helada"
        71, 73, 75, 77 -> "nieve"
        80, 81 -> "chubascos"
        82 -> "chubascos fuertes"
        85, 86 -> "chubascos de nieve"
        95 -> "tormenta"
        96, 99 -> "tormenta con granizo"
        else -> "tiempo variable"
    }

    private class Place(val name: String, val lat: Double, val lon: Double)

    private fun geocode(city: String): Place? {
        val url = "https://geocoding-api.open-meteo.com/v1/search?name=" +
            URLEncoder.encode(city, "UTF-8") + "&count=1&language=es&format=json"
        val r = JSONObject(Net.get(url)).optJSONArray("results") ?: return null
        if (r.length() == 0) return null
        val o = r.getJSONObject(0)
        return Place(o.optString("name", city), o.getDouble("latitude"), o.getDouble("longitude"))
    }

    private fun lastLocation(ctx: Context): Place? {
        if (ctx.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        return try {
            val lm = ctx.getSystemService(LocationManager::class.java)
            val best = lm.getProviders(true).mapNotNull { lm.getLastKnownLocation(it) }.maxByOrNull { it.time }
            if (best == null) null else Place("donde estás", best.latitude, best.longitude)
        } catch (e: Exception) {
            null
        }
    }

    /** [city] vacío = ciudad de los ajustes, o tu ubicación, o se pregunta. */
    fun report(ctx: Context, city: String?, tomorrow: Boolean, reply: (String) -> Unit) {
        val app = ctx.applicationContext
        val wanted = city?.takeIf { it.isNotBlank() } ?: Prefs.city(app).takeIf { it.isNotBlank() }
        val here = if (wanted == null) lastLocation(app) else null
        if (wanted == null && here == null) {
            Conversation.ask { c, answer, r -> report(c, answer.trim(), tomorrow, r) }
            reply("¿De qué ciudad quieres el tiempo?")
            return
        }
        Net.background({
            val place = here ?: geocode(wanted!!)
            if (place == null) null else place to Net.get(
                "https://api.open-meteo.com/v1/forecast?latitude=${place.lat}&longitude=${place.lon}" +
                    "&current=temperature_2m,weather_code,wind_speed_10m" +
                    "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max" +
                    "&timezone=auto&forecast_days=2"
            )
        }) { res, err ->
            if (err != null) {
                reply(if (err is java.io.IOException) "No tengo internet para mirar el tiempo." else "No he podido consultar el tiempo.")
                return@background
            }
            if (res == null) { reply("No encuentro la ciudad $wanted."); return@background }
            try {
                val place = res.first
                val j = JSONObject(res.second)
                val d = j.getJSONObject("daily")
                val idx = if (tomorrow) 1 else 0
                val max = Math.round(d.getJSONArray("temperature_2m_max").getDouble(idx))
                val min = Math.round(d.getJSONArray("temperature_2m_min").getDouble(idx))
                val rain = d.getJSONArray("precipitation_probability_max").optInt(idx, 0)
                val desc = describe(d.getJSONArray("weather_code").getInt(idx))
                val where = if (place.name == "donde estás") "donde estás" else "en ${place.name}"
                val text = if (tomorrow) {
                    "Mañana $where: $desc, máxima de $max grados y mínima de $min. Probabilidad de lluvia, el $rain por ciento."
                } else {
                    val cur = j.getJSONObject("current")
                    val now = Math.round(cur.getDouble("temperature_2m"))
                    val nowDesc = describe(cur.getInt("weather_code"))
                    "Ahora $where hay $now grados y $nowDesc. Hoy máxima de $max y mínima de $min. Probabilidad de lluvia, el $rain por ciento."
                }
                reply(text)
            } catch (e: Exception) {
                reply("No he entendido la respuesta del tiempo.")
            }
        }
    }
}
