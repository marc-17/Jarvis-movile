package app.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService

/** Permite a Jarvis leerte las notificaciones ("Jarvis, lee mis notificaciones"). Se activa en Ajustes > Acceso a notificaciones. */
class JarvisNotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: JarvisNotificationService? = null

        fun summary(): String {
            val s = instance ?: return "Activa el acceso a notificaciones de Jarvis en los ajustes."
            val list = try { s.activeNotifications.toList() } catch (e: Exception) { emptyList() }
            val pm = s.packageManager
            val lines = ArrayList<String>()
            for (sbn in list) {
                if (sbn.packageName == s.packageName) continue
                val extras = sbn.notification.extras
                val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) continue
                val app = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                } catch (e: Exception) {
                    sbn.packageName
                }
                lines.add("$app: $title. $text".trim())
                if (lines.size >= 8) break
            }
            return if (lines.isEmpty()) "No tienes notificaciones." else lines.joinToString(" ")
        }
    }

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }
}
