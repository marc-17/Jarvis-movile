package app.jarvis

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Permite a Jarvis leerte las notificaciones ("Jarvis, lee mis notificaciones"). Se activa en Ajustes > Acceso a notificaciones. */
class JarvisNotificationService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: JarvisNotificationService? = null

        /** Quién está llamando ahora mismo (null si no suena nada). */
        @Volatile
        var caller: String? = null
        private var callerKey: String? = null
        private val announced = HashSet<String>()

        fun summary(): String {
            val s = instance ?: return "Activa el acceso a notificaciones de Jarvis en los ajustes."
            val list = try { s.activeNotifications.toList() } catch (e: Exception) { emptyList() }
            val pm = s.packageManager
            val lines = ArrayList<String>()
            for (sbn in list) {
                if (sbn.packageName == s.packageName) continue
                val extras = sbn.notification.extras
                val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
                val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
                if (title.isBlank() && text.isBlank()) continue
                val app = try {
                    pm.getApplicationLabel(pm.getApplicationInfo(sbn.packageName, 0)).toString()
                } catch (e: Exception) {
                    sbn.packageName
                }
                lines.add("$app: $title. $text".trim())
                if (lines.size >= 8) break
            }
            return if (lines.isEmpty()) "No tienes notificaciones." else lines.joinToString(" ")
        }
    }

    private val answerWords = Regex("contest|respond|answer|accept|acept|coger")
    private val genericTitle = Regex("llamada|incoming|entrante|calling|llamando")

    /** Detecta la notificación de llamada entrante y dice quién llama. */
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (n.category != Notification.CATEGORY_CALL) return
        val incoming = n.actions?.any { a -> answerWords.containsMatchIn(Text.norm(a.title?.toString().orEmpty())) } == true
        if (!incoming) return
        val ex = n.extras
        var who = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        if (who.isBlank() || genericTitle.containsMatchIn(Text.norm(who))) {
            who = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty().ifBlank { who }
        }
        if (who.isBlank()) return
        // Los números se leen cifra a cifra
        val digits = who.filter { it.isDigit() }
        val spoken = if (digits.length >= 6 && who.none { it.isLetter() }) digits.toList().joinToString(" ") else who
        caller = spoken
        callerKey = sbn.key
        if (announced.add(sbn.key) && Prefs.getBool(this, "announce_calls", true)) {
            Speaker.say(this, "Te llama $spoken. Di Jarvis contesta, o Jarvis cuelga.")
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        announced.remove(sbn.key)
        if (sbn.key == callerKey) { caller = null; callerKey = null }
    }

    override fun onListenerConnected() {
        instance = this
    }

    override fun onListenerDisconnected() {
        instance = null
    }
}
