package app.jarvis

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.Manifest
import android.os.Build
import android.os.IBinder

/**
 * Modo pantalla rota: escucha todo el rato y solo hace caso a lo que empiece por "Jarvis".
 * Ej.: "Jarvis, abre TikTok" / "Jarvis, baja" / "Jarvis, pulsa aceptar".
 */
class ContinuousService : Service() {

    companion object {
        const val ACTION_STOP = "app.jarvis.STOP"
        private const val CHANNEL = "jarvis_listening"
        private const val NOTIF_ID = 1
        @Volatile
        var running = false
    }

    private var listener: VoiceListener? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (listener == null) {
            val l = VoiceListener(this, true, onText = { text ->
                CommandEngine.handle(this, text, true) { reply ->
                    listener?.pause()
                    Speaker.say(this, reply) { listener?.resume() }
                }
            })
            listener = l
            l.start()
        }
        running = true
        return START_STICKY
    }

    override fun onDestroy() {
        running = false
        listener?.stop()
        listener = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Jarvis escuchando", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, ContinuousService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setContentTitle("Jarvis está escuchando")
            .setContentText("Di «Jarvis» y una orden")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause), "Parar", stop
                ).build()
            )
            .setOngoing(true)
            .build()
    }
}
