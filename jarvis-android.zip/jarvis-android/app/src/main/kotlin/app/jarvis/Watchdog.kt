package app.jarvis

import android.app.Application
import android.content.Context
import android.os.Handler
import android.os.Looper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/** Se instancia al arrancar la app: vigila que el hilo principal no se quede colgado. */
class JarvisApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Watchdog.start(this)
    }
}

/**
 * Detector de bloqueos («Jarvis no responde»). Cada 3 segundos comprueba que el hilo principal sigue vivo;
 * si lleva colgado más de 3 s, apunta QUÉ está haciendo en ese momento. Se ve en la app, sección «Diagnóstico».
 */
object Watchdog {
    private var started = false

    fun start(ctx: Context) {
        if (started) return
        started = true
        val app = ctx.applicationContext
        val main = Handler(Looper.getMainLooper())
        Thread {
            while (true) {
                val alive = AtomicBoolean(false)
                main.post { alive.set(true) }
                try { Thread.sleep(3000) } catch (_: InterruptedException) { return@Thread }
                if (!alive.get()) {
                    val stack = Looper.getMainLooper().thread.stackTrace.take(30).joinToString("\n") { "   at $it" }
                    record(app, stack)
                    var waited = 0
                    while (!alive.get() && waited < 120) {
                        try { Thread.sleep(500) } catch (_: InterruptedException) { return@Thread }
                        waited++
                    }
                }
            }
        }.also { it.isDaemon = true }.start()
    }

    @Synchronized
    private fun record(ctx: Context, stack: String) {
        val stamp = SimpleDateFormat("d/M HH:mm:ss", Locale("es", "ES")).format(Date())
        val old = Prefs.get(ctx, "stalls", "")
        val entries = (if (old.isEmpty()) emptyList() else old.split("\n=====\n")).takeLast(4)
        Prefs.put(ctx, "stalls", (entries + "[$stamp] El hilo principal se quedó colgado más de 3 s:\n$stack").joinToString("\n=====\n"))
    }

    fun read(ctx: Context): String = Prefs.get(ctx, "stalls", "")
    fun clear(ctx: Context) = Prefs.put(ctx, "stalls", "")
}
