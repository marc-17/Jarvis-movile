package app.jarvis

import android.content.Context

/**
 * Conversación de varios turnos. Cuando Jarvis hace una pregunta ("¿Qué le pongo?") deja aquí un "siguiente paso":
 * la próxima frase que oiga NO se interpreta como una orden nueva, sino que va a ese paso.
 * Quien escucha (ListenActivity / ContinuousService) mira [waiting] después de hablar para seguir escuchando.
 */
typealias ConvStep = (Context, String, (String) -> Unit) -> Unit

object Conversation {
    private var step: ConvStep? = null
    private var expires = 0L

    /** true en el dictado: se aguantan silencios más largos sin cortar la conversación. */
    @Volatile
    var patient = false
        private set

    val waiting: Boolean get() = step != null && System.currentTimeMillis() < expires

    /** Registra qué hacer con la próxima respuesta. Llamar ANTES de decir la pregunta. */
    fun ask(timeoutMs: Long = 45000, patient: Boolean = false, handler: ConvStep) {
        this.patient = patient
        step = handler
        expires = System.currentTimeMillis() + timeoutMs
    }

    /** Saca el paso pendiente (o null si no hay o caducó). */
    fun take(): ConvStep? {
        val s = if (waiting) step else null
        step = null
        return s
    }

    fun clear() { step = null; patient = false }

    private val cancel = Regex("(cancela|cancelar|cancelalo|olvidalo|olvida|dejalo|deja lo|dejalo estar|da igual|no importa|nada|nada nada|ya no|dejalo ya)")
    fun isCancel(norm: String) = cancel.matches(norm)

    private val yes = Regex("(si|sii|vale|venga|dale|ok|okey|claro|por supuesto|adelante|hazlo|envialo|enviar|mandalo|manda lo|si envialo|si mandalo|si por favor|si claro|afirmativo|correcto|exacto|eso es|perfecto|de acuerdo|si si)")
    private val no = Regex("(no|nop|no gracias|negativo|no lo envies|no lo mandes|para|no no)")
    fun isYes(norm: String) = yes.matches(norm)
    fun isNo(norm: String) = no.matches(norm)

    fun leansYes(norm: String) = Regex("^(si|vale|venga|dale|ok|okey|claro|envia|manda|adelante)( |$)").containsMatchIn(norm)
    fun leansNo(norm: String) = Regex("^(no|nada|cancela|mejor no)( |$)").containsMatchIn(norm)
}
