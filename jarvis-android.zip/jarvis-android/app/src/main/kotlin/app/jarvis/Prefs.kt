package app.jarvis

import android.content.Context
import android.content.SharedPreferences

/** Ajustes guardados en el móvil (la clave de Gemini vive AQUÍ, nunca en el código). */
object Prefs {
    private fun sp(ctx: Context): SharedPreferences =
        ctx.applicationContext.getSharedPreferences("jarvis", Context.MODE_PRIVATE)

    fun get(ctx: Context, key: String, def: String = ""): String = sp(ctx).getString(key, def) ?: def
    fun put(ctx: Context, key: String, value: String) { sp(ctx).edit().putString(key, value).apply() }
    fun getBool(ctx: Context, key: String, def: Boolean): Boolean = sp(ctx).getBoolean(key, def)
    fun putBool(ctx: Context, key: String, value: Boolean) { sp(ctx).edit().putBoolean(key, value).apply() }
    fun nextId(ctx: Context): Int {
        val n = sp(ctx).getInt("next_id", 1)
        sp(ctx).edit().putInt("next_id", n + 1).apply()
        return n
    }

    fun geminiKey(ctx: Context) = get(ctx, "gemini_key").trim()
    fun geminiModel(ctx: Context) = get(ctx, "gemini_model").trim().ifEmpty { Gemini.DEFAULT_MODEL }
    fun city(ctx: Context) = get(ctx, "city").trim()
    /** Pedir "¿Lo envío?" antes de mandar un mensaje. */
    fun confirmSend(ctx: Context) = getBool(ctx, "confirm_send", true)
}
