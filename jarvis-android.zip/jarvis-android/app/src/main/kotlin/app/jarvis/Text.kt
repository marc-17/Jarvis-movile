package app.jarvis

import java.text.Normalizer
import java.util.Locale

/** Normaliza lo que oye el reconocedor: minúsculas, sin tildes ni signos. "¡Jarvis, pon Ozuna!" -> "jarvis pon ozuna". */
object Text {
    private val accents = Regex("\\p{InCombiningDiacriticalMarks}+")
    private val nonAlnum = Regex("[^a-z0-9 ]")
    private val spaces = Regex("\\s+")

    fun norm(s: String): String {
        val lower = s.lowercase(Locale("es", "ES"))
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD).replace(accents, "")
        return noAccents.replace(nonAlnum, " ").replace(spaces, " ").trim()
    }

    private val words = mapOf(
        "un" to 1, "una" to 1, "uno" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "quince" to 15,
        "veinte" to 20, "treinta" to 30, "cuarenta" to 40, "cincuenta" to 50, "sesenta" to 60
    )

    /** Convierte "5", "cinco", "un" en número; null si no es número. */
    fun number(token: String): Int? = token.toIntOrNull() ?: words[token]

    /** "1 hora 30 minutos" / "cinco minutos" / "45 segundos" -> segundos. null si no entiende nada. */
    fun durationSeconds(s: String): Int? {
        val re = Regex("(\\d+|un|una|uno|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez|quince|veinte|treinta|cuarenta|cincuenta|sesenta) ?(hora|horas|minuto|minutos|min|segundo|segundos)")
        var total = 0
        var found = false
        for (m in re.findAll(s)) {
            val n = number(m.groupValues[1]) ?: continue
            val unit = m.groupValues[2]
            total += when {
                unit.startsWith("hora") -> n * 3600
                unit.startsWith("min") -> n * 60
                else -> n
            }
            found = true
        }
        return if (found) total else null
    }
}
