package app.jarvis

import java.util.Locale

/** Calculadora para "cuánto es 25 por 4", "el 20 por ciento de 150", etc. Entrada ya normalizada (Text.norm). */
object Calc {
    private val numWords = mapOf(
        "cero" to 0, "un" to 1, "uno" to 1, "una" to 1, "dos" to 2, "tres" to 3, "cuatro" to 4, "cinco" to 5,
        "seis" to 6, "siete" to 7, "ocho" to 8, "nueve" to 9, "diez" to 10, "once" to 11, "doce" to 12,
        "trece" to 13, "catorce" to 14, "quince" to 15, "veinte" to 20, "treinta" to 30, "cuarenta" to 40,
        "cincuenta" to 50, "sesenta" to 60, "setenta" to 70, "ochenta" to 80, "noventa" to 90, "cien" to 100,
        "mil" to 1000
    )

    private fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "no definido"
        return if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else String.format(Locale("es", "ES"), "%.2f", v)
    }

    /** Devuelve la frase con el resultado, o null si no es una operación que entienda. */
    fun answer(input: String): String? {
        var s = " $input "
        // porcentaje: "el 20 por ciento de 150"
        Regex(" (?:el )?(\\d+(?: coma \\d+)?) por ciento de (\\d+(?: coma \\d+)?) ").find(s)?.let {
            val p = num(it.groupValues[1]) ?: return null
            val b = num(it.groupValues[2]) ?: return null
            return "El ${fmt(p)} por ciento de ${fmt(b)} es ${fmt(p * b / 100.0)}"
        }
        s = s.replace(Regex("(\\d+) coma (\\d+)"), "$1.$2")
        s = s.replace(" multiplicado por ", " * ").replace(" multiplicado ", " * ")
            .replace(" dividido entre ", " / ").replace(" dividido por ", " / ").replace(" partido por ", " / ")
            .replace(" dividido ", " / ").replace(" entre ", " / ")
            .replace(" mas ", " + ").replace(" menos ", " - ").replace(" por ", " * ").replace(" x ", " * ")
        s = s.replace(" al cuadrado ", " ^ 2 ").replace(" al cubo ", " ^ 3 ").replace(" elevado a ", " ^ ")
        s = s.replace(Regex("\\bde\\b"), " ")
        for ((w, n) in numWords) s = s.replace(Regex("\\b$w\\b"), n.toString())
        s = s.replace(" y ", " + ")
        val tokens = Regex("\\d+(?:\\.\\d+)?|[-+*/^()]").findAll(s).map { it.value }.toList()
        if (tokens.isEmpty()) return null
        // Debe quedar solo operación: si hay letras sueltas, no es una cuenta
        val letters = s.replace(Regex("\\d+(?:\\.\\d+)?|[-+*/^() ]"), "")
        if (letters.isNotEmpty()) return null
        return try {
            val p = Parser(tokens)
            val v = p.expr()
            if (!p.atEnd()) null else {
                val shown = tokens.joinToString(" ").replace("*", "por").replace("/", "entre").replace("+", "más")
                    .replace(" - ", " menos ").replace("^", "elevado a")
                "$shown es ${fmt(v)}"
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun num(s: String): Double? = s.replace(" coma ", ".").toDoubleOrNull()

    private class Parser(val t: List<String>) {
        var i = 0
        fun atEnd() = i >= t.size
        fun expr(): Double {
            var v = term()
            while (i < t.size && (t[i] == "+" || t[i] == "-")) {
                val op = t[i++]
                val r = term()
                v = if (op == "+") v + r else v - r
            }
            return v
        }
        fun term(): Double {
            var v = pow()
            while (i < t.size && (t[i] == "*" || t[i] == "/")) {
                val op = t[i++]
                val r = pow()
                v = if (op == "*") v * r else v / r
            }
            return v
        }
        fun pow(): Double {
            val b = atom()
            if (i < t.size && t[i] == "^") { i++; return Math.pow(b, pow()) }
            return b
        }
        fun atom(): Double {
            if (i >= t.size) throw IllegalStateException()
            val x = t[i++]
            if (x == "(") { val v = expr(); if (i < t.size && t[i] == ")") i++; return v }
            if (x == "-") return -atom()
            return x.toDouble()
        }
    }
}
