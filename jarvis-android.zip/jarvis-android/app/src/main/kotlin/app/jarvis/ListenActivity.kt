package app.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Ventanita que sale abajo cuando invocas a Jarvis. Te escucha, ejecuta la orden y, si Jarvis te ha hecho una
 * pregunta ("¿Qué le pongo?"), sigue escuchando hasta terminar la conversación.
 *
 * La ventana ocupa solo la tarjeta de abajo y NO se queda con los toques ni con el foco: así los toques, el scroll
 * y las pulsaciones que hace Jarvis llegan a la app que hay debajo.
 */
class ListenActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private var listener: VoiceListener? = null
    private lateinit var status: TextView
    private var done = false
    private var turn = 0
    private var retries = 0
    private val timeout = Runnable { finishNow() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        window.setGravity(Gravity.BOTTOM)
        window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        window.addFlags(WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL)

        val dp = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val pad = (20 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61F2937"))
                cornerRadius = 24 * dp
            }
        }
        status = TextView(this).apply {
            text = "Te escucho…"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        card.addView(status)

        val root = LinearLayout(this).apply {
            gravity = Gravity.BOTTOM
            val m = (16 * dp).toInt()
            setPadding(m, m, m, m * 2)
        }
        root.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        card.setOnClickListener { finishNow() }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Speaker.say(this, "Necesito permiso de micrófono.")
            finishNow()
            return
        }

        Conversation.clear() // una invocación nueva empieza de cero
        listen()
    }

    private fun listen() {
        if (done) return
        listener?.stop()
        status.text = if (turn == 0) "Te escucho…" else "Te escucho… (responde)"
        listener = VoiceListener(this, false,
            onText = { text -> onHeard(text) },
            onError = { code -> onFail(code) })
        listener?.start()
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, 25000)
    }

    private fun onHeard(text: String) {
        listener?.stop()
        retries = 0
        turn++
        status.text = "“$text”"
        main.removeCallbacks(timeout)
        main.postDelayed(timeout, 40000) // por si Gemini o la red tardan
        CommandEngine.handle(this, text, false, { reply ->
            if (!done) {
                status.text = reply
                main.removeCallbacks(timeout)
                main.postDelayed(timeout, 40000)
                Speaker.say(this, reply) { afterSpeaking() }
            }
        })
    }

    private fun afterSpeaking() {
        if (done) return
        if (Conversation.waiting) listen() else main.postDelayed({ finishNow() }, 400)
    }

    private fun onFail(code: Int) {
        if (done) return
        val silent = code == SpeechRecognizer.ERROR_NO_MATCH || code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
        if (Conversation.waiting && silent && retries < 1) {
            retries++
            listen()
            return
        }
        Conversation.clear()
        status.text = when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> if (turn > 0) "Vale, lo dejo." else "No te he oído."
            SpeechRecognizer.ERROR_CLIENT -> "Este móvil no tiene reconocimiento de voz."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta el permiso de micrófono."
            else -> "Error de voz ($code)."
        }
        main.removeCallbacks(timeout)
        main.postDelayed({ finishNow() }, 1500)
    }

    private fun finishNow() {
        if (done) return
        done = true
        listener?.stop()
        main.removeCallbacksAndMessages(null)
        finish()
    }

    override fun onDestroy() {
        done = true
        listener?.stop()
        super.onDestroy()
    }
}
