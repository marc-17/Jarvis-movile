package app.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

/** Ventanita que sale abajo cuando invocas a Jarvis: te escucha una frase, la ejecuta y se cierra. */
class ListenActivity : Activity() {

    private val main = Handler(Looper.getMainLooper())
    private var listener: VoiceListener? = null
    private lateinit var status: TextView
    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setShowWhenLocked(true)
        setTurnScreenOn(true)

        val dp = resources.displayMetrics.density
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            val pad = (20 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E61F2937"))
                cornerRadius = 24 * dp
            }
        }
        status = TextView(this).apply {
            text = "Te escucho…"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        }
        card.addView(status)

        val root = LinearLayout(this).apply {
            gravity = Gravity.BOTTOM
            val m = (16 * dp).toInt()
            setPadding(m, m, m, m * 2)
        }
        root.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        setContentView(root)
        root.setOnClickListener { finishNow() }

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Speaker.say(this, "Necesito permiso de micrófono.")
            finishNow()
            return
        }

        listener = VoiceListener(this, false,
            onText = { text -> onHeard(text) },
            onError = { code -> onFail(code) })
        listener?.start()

        // Seguro por si algo se queda colgado
        main.postDelayed({ finishNow() }, 20000)
    }

    private fun onHeard(text: String) {
        status.text = "“$text”"
        CommandEngine.handle(this, text, false) { reply ->
            status.text = reply
            Speaker.say(this, reply) { main.postDelayed({ finishNow() }, 400) }
        }
    }

    private fun onFail(code: Int) {
        val msg = when (code) {
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "No te he oído."
            SpeechRecognizer.ERROR_CLIENT -> "Este móvil no tiene reconocimiento de voz."
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Falta el permiso de micrófono."
            else -> "Error de voz ($code)."
        }
        status.text = msg
        main.postDelayed({ finishNow() }, 1500)
    }

    private fun finishNow() {
        if (done) return
        done = true
        listener?.stop()
        main.removeCallbacksAndMessages(null)
        finish()
    }

    override fun onDestroy() {
        listener?.stop()
        super.onDestroy()
    }
}
