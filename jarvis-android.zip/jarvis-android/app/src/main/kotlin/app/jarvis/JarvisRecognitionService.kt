package app.jarvis

import android.content.Intent
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/**
 * Android exige que un asistente de voz declare un servicio de reconocimiento. Este no reconoce nada:
 * Jarvis escucha usando el reconocedor de Google (ver VoiceListener), así que aquí solo se devuelve un error.
 */
class JarvisRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (_: Exception) {
        }
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
