package app.jarvis

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

/** Voz de Jarvis (TextToSpeech del sistema, en español). Singleton para que siga hablando aunque se cierre una pantalla. */
object Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private val queue = ArrayList<Pair<String, (() -> Unit)?>>()
    private val callbacks = HashMap<String, (() -> Unit)?>()

    private fun ensure(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("es", "ES")
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) = finish(utteranceId)
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) = finish(utteranceId)
                    })
                    ready = true
                    queue.forEach { speakNow(it.first, it.second) }
                } else {
                    queue.forEach { it.second?.invoke() }
                }
                queue.clear()
            }
        }
    }

    private fun finish(id: String?) {
        val cb = callbacks.remove(id)
        if (cb != null) main.post { cb() }
    }

    private fun speakNow(text: String, onDone: (() -> Unit)?) {
        val id = UUID.randomUUID().toString()
        callbacks[id] = onDone
        tts?.speak(text, TextToSpeech.QUEUE_ADD, null, id)
    }

    /** Dice [text]; al terminar llama a [onDone] (en el hilo principal). */
    fun say(ctx: Context, text: String, onDone: (() -> Unit)? = null) {
        main.post {
            ensure(ctx)
            if (ready) speakNow(text, onDone) else queue.add(text to onDone)
        }
    }

    fun stop() {
        main.post { tts?.stop() }
    }
}
