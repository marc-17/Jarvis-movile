package app.jarvis

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import java.util.Locale
import java.util.UUID

/**
 * Voz de Jarvis (TextToSpeech del sistema). Singleton con cola: las frases se dicen una detrás de otra,
 * cada una puede ir en su idioma, y el aviso de "terminé" salta cuando de verdad ha acabado de hablar.
 * Una frase vacía solo sirve para esperar a que se vacíe la cola.
 */
object Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    private var appCtx: Context? = null

    private class Item(val text: String, val locale: Locale?, val cb: (() -> Unit)?)

    private val queue = ArrayDeque<Item>()
    private var speaking = false
    private var currentId: String? = null
    private var currentCb: (() -> Unit)? = null
    private val onReady = ArrayList<() -> Unit>()

    private val spanish = Locale("es", "ES")

    private fun ensure(ctx: Context) {
        if (tts != null) return
        appCtx = ctx.applicationContext
        tts = TextToSpeech(appCtx) { status ->
            main.post {
                if (status == TextToSpeech.SUCCESS) {
                    tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) { main.post { finish(utteranceId) } }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) { main.post { finish(utteranceId) } }
                    })
                    ready = true
                    onReady.toList().forEach { it() }
                    onReady.clear()
                    pump()
                } else {
                    // Sin voz: se avisa a todos para que no se queden esperando
                    val all = queue.toList()
                    queue.clear()
                    all.forEach { it.cb?.invoke() }
                }
            }
        }
    }

    private fun applySettings(locale: Locale?) {
        val t = tts ?: return
        val c = appCtx
        if (locale != null) {
            t.language = locale
        } else {
            t.language = spanish
            val saved = if (c != null) Prefs.get(c, "tts_voice") else ""
            val voice = if (saved.isNotEmpty()) t.voices?.firstOrNull { it.name == saved } else null
            if (voice != null) t.voice = voice
        }
        val rate = if (c != null) Prefs.get(c, "tts_rate", "1.0").toFloatOrNull() ?: 1f else 1f
        t.setSpeechRate(rate.coerceIn(0.5f, 2.5f))
    }

    private fun pump() {
        if (!ready || speaking) return
        val item = queue.removeFirstOrNull() ?: return
        if (item.text.isBlank()) {
            item.cb?.invoke()
            pump()
            return
        }
        val t = tts ?: return
        applySettings(item.locale)
        val id = UUID.randomUUID().toString()
        speaking = true
        currentId = id
        currentCb = item.cb
        val r = t.speak(item.text.take(3500), TextToSpeech.QUEUE_FLUSH, null, id)
        if (r != TextToSpeech.SUCCESS) { finish(id); return }
        // Por si el motor se cuelga y nunca avisa
        main.postDelayed({ finish(id) }, 8000L + item.text.length * 130L)
    }

    private fun finish(id: String?) {
        if (id == null || id != currentId) return
        speaking = false
        currentId = null
        val cb = currentCb
        currentCb = null
        cb?.invoke()
        pump()
    }

    /** Dice [text] (en [locale], o en español); al terminar llama a [onDone] en el hilo principal. */
    fun say(ctx: Context, text: String, locale: Locale? = null, onDone: (() -> Unit)? = null) {
        main.post {
            ensure(ctx)
            queue.addLast(Item(text, locale, onDone))
            pump()
        }
    }

    fun stop() {
        main.post {
            queue.clear()
            tts?.stop()
            speaking = false
            currentId = null
            currentCb = null
        }
    }

    /** Voces en español instaladas (para elegir la más natural en los ajustes). */
    fun withVoices(ctx: Context, cb: (List<Voice>) -> Unit) {
        main.post {
            ensure(ctx)
            val deliver = {
                val list = (tts?.voices ?: emptySet<Voice>())
                    .filter { it.locale.language == "es" && !it.features.contains("notInstalled") }
                    .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.name })
                cb(list)
            }
            if (ready) deliver() else onReady.add(deliver)
        }
    }
}
