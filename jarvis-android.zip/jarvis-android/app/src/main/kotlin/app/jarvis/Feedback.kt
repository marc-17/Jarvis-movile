package app.jarvis

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator

/** Pitido y vibración para saber que Jarvis te ha oído sin mirar el móvil. */
object Feedback {
    private val main = Handler(Looper.getMainLooper())

    private fun enabled(ctx: Context) = Prefs.getBool(ctx, "feedback", true)

    private fun vibrate(ctx: Context, ms: Long) {
        try {
            val v = ctx.getSystemService(Vibrator::class.java)
            v?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    /** "Te escucho": pitido corto + vibración. */
    fun ready(ctx: Context) {
        if (!enabled(ctx)) return
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 100)
            main.postDelayed({ try { tg.release() } catch (_: Exception) {} }, 400)
        } catch (_: Exception) {
        }
        vibrate(ctx, 60)
    }

    /** "Te he entendido": vibración muy corta. */
    fun ok(ctx: Context) {
        if (enabled(ctx)) vibrate(ctx, 35)
    }
}
