package app.jarvis

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Llamada a la API de Gemini (REST, sin librerías). La clave sale de los ajustes de la app. */
object Gemini {
    const val DEFAULT_MODEL = "gemini-3.5-flash-lite"

    fun configured(ctx: Context) = Prefs.geminiKey(ctx).isNotEmpty()

    /**
     * Bloqueante: llamar desde un hilo (Net.background). [turns] = lista de (rol, texto), rol "user" o "model";
     * el último debe ser "user". Devuelve el texto de la respuesta.
     */
    fun generate(ctx: Context, system: String, turns: List<Pair<String, String>>, json: Boolean, image: ByteArray? = null): String {
        val key = Prefs.geminiKey(ctx)
        val model = Prefs.geminiModel(ctx)
        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
        val contents = JSONArray()
        for ((index, turn) in turns.withIndex()) {
            val (role, text) = turn
            val parts = JSONArray().put(JSONObject().put("text", text))
            if (image != null && index == turns.size - 1) {
                parts.put(
                    JSONObject().put(
                        "inline_data",
                        JSONObject().put("mime_type", "image/jpeg")
                            .put("data", android.util.Base64.encodeToString(image, android.util.Base64.NO_WRAP))
                    )
                )
            }
            contents.put(JSONObject().put("role", role).put("parts", parts))
        }
        body.put("contents", contents)
        val gc = JSONObject().put("maxOutputTokens", 1024)
        if (json) gc.put("responseMimeType", "application/json")
        body.put("generationConfig", gc)

        val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
        val resp = Net.postJson(url, body.toString(), mapOf("x-goog-api-key" to key), if (image != null) 30000 else 15000)
        val parts = JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val p = parts.getJSONObject(i)
            if (p.optBoolean("thought", false)) continue
            sb.append(p.optString("text", ""))
        }
        return sb.toString().trim()
    }

    /** Mensaje entendible para el usuario cuando algo falla. */
    fun explain(e: Throwable): String = when {
        e is Net.HttpException && (e.code == 400 || e.code == 401 || e.code == 403) ->
            if (e.body.contains("API key", true) || e.code != 400)
                "La clave de Gemini no vale o no tiene permiso. Revísala en los ajustes de Jarvis."
            else "Gemini ha rechazado la petición. Puede que el nombre del modelo sea incorrecto."
        e is Net.HttpException && e.code == 404 -> "Ese modelo de Gemini no existe. Cámbialo en los ajustes de Jarvis."
        e is Net.HttpException && e.code == 429 -> "Gemini está saturado o he gastado el límite gratis. Prueba en un minuto."
        e is Net.HttpException -> "Gemini ha dado un error (${e.code})."
        e is java.net.UnknownHostException || e is java.net.SocketTimeoutException || e is java.net.ConnectException ->
            "No tengo internet ahora mismo."
        else -> "No he podido hablar con Gemini."
    }
}
