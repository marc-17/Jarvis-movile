package app.jarvis

import android.app.Notification
import android.app.PendingIntent
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle

/**
 * Leer los mensajes que te llegan (WhatsApp, Telegram, SMS...) y contestarlos sin abrir la app,
 * usando el botón "Responder" de la propia notificación.
 */
object IncomingReply {
    class Msg(val sender: String, val lines: List<String>, val action: Notification.Action, val time: Long)

    private fun replyAction(n: Notification): Notification.Action? =
        n.actions?.firstOrNull { a -> a.remoteInputs?.any { it.allowFreeFormInput } == true }

    @Suppress("DEPRECATION")
    private fun linesOf(n: Notification): List<String> {
        val ex = n.extras
        val out = ArrayList<String>()
        try {
            val arr = ex.getParcelableArray(Notification.EXTRA_MESSAGES)
            if (arr != null) {
                for (m in Notification.MessagingStyle.Message.getMessagesFromBundleArray(arr)) {
                    val who = m.senderPerson?.name?.toString()
                    val t = m.text?.toString() ?: continue
                    out.add(if (who.isNullOrBlank()) t else "$who: $t")
                }
            }
        } catch (_: Exception) {
        }
        if (out.isEmpty()) {
            ex.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.takeIf { it.isNotBlank() }?.let { out.add(it) }
        }
        return out
    }

    /** Conversaciones con mensajes sin contestar que se pueden responder desde la notificación. */
    fun recent(): List<Msg> {
        val svc = JarvisNotificationService.instance ?: return emptyList()
        val list = try { svc.activeNotifications.toList() } catch (e: Exception) { emptyList() }
        val out = ArrayList<Msg>()
        for (sbn in list) {
            if (sbn.packageName == svc.packageName) continue
            val n = sbn.notification
            if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) continue
            val action = replyAction(n) ?: continue
            val title = n.extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            if (title.isBlank()) continue
            val lines = linesOf(n)
            if (lines.isEmpty()) continue
            out.add(Msg(title, lines, action, sbn.postTime))
        }
        return out.sortedByDescending { it.time }
    }

    /** Los mensajes sin contestar como texto plano (para resumirlos con Gemini). */
    fun asText(): String = recent().joinToString("\n") { m -> "${m.sender}: " + m.lines.takeLast(5).joinToString(" | ") }

    /** "Lee mis mensajes". */
    fun readAndOffer(ctx: Context, reply: (String) -> Unit) {
        if (JarvisNotificationService.instance == null) {
            reply("Activa el acceso a notificaciones de Jarvis en los ajustes."); return
        }
        val msgs = recent()
        if (msgs.isEmpty()) { reply("No tienes mensajes nuevos."); return }
        val head = if (msgs.size == 1) "Tienes un mensaje. " else "Tienes ${msgs.size} conversaciones. "
        val body = msgs.take(4).joinToString(" ") { m ->
            val last = m.lines.takeLast(3).joinToString(". ")
            "${m.sender}: $last."
        }
        val latest = msgs.first()
        Conversation.ask { c, ans, r ->
            val n = Text.norm(ans)
            when {
                Conversation.isYes(n) || Conversation.leansYes(n) -> replyTo(c, latest.sender, null, r)
                Conversation.isNo(n) || Conversation.leansNo(n) -> r("Vale.")
                else -> replyTo(c, latest.sender, ans.trim(), r) // ya dijo directamente qué contestar
            }
        }
        reply(head + body + " ¿Quieres contestar a ${latest.sender}?")
    }

    /**
     * Contesta a [who] (o al último mensaje recibido si es null) con [text] (si es null, lo pregunta).
     * Si no hay ninguna notificación de esa persona, manda un WhatsApp nuevo.
     */
    fun replyTo(ctx: Context, who: String?, text: String?, reply: (String) -> Unit) {
        val msgs = recent()
        val target = if (who == null) msgs.firstOrNull() else {
            val w = Apps.normWho(who)
            msgs.firstOrNull { val s = Text.norm(it.sender); s == w || s.contains(w) || w.contains(s) }
        }
        if (target == null) {
            if (who != null) Messaging.start(ctx, "whatsapp", who, text, reply)
            else reply("No tienes ningún mensaje al que contestar.")
            return
        }
        if (text.isNullOrBlank()) {
            Conversation.ask { c, ans, r -> replyTo(c, target.sender, ans.trim(), r) }
            reply("¿Qué le digo a ${target.sender}?")
            return
        }
        if (!Prefs.confirmSend(ctx)) { sendNow(ctx, target, text, reply); return }
        Messaging.confirm(
            "Le digo a ${target.sender}: $text. ¿Lo envío?", reply,
            onChange = { c, newText, r -> replyTo(c, target.sender, newText, r) },
            onYes = { r -> sendNow(ctx, target, text, r) }
        )
    }

    private fun sendNow(ctx: Context, m: Msg, text: String, reply: (String) -> Unit) {
        val inputs = m.action.remoteInputs
        if (inputs == null || inputs.isEmpty()) { reply("No puedo contestar a ese mensaje."); return }
        try {
            val intent = Intent()
            val b = Bundle()
            for (ri in inputs) b.putCharSequence(ri.resultKey, text)
            RemoteInput.addResultsToIntent(inputs, intent, b)
            m.action.actionIntent.send(ctx, 0, intent)
            reply("Enviado a ${m.sender}")
        } catch (e: PendingIntent.CanceledException) {
            reply("Ese mensaje ya no se puede contestar desde aquí. Abre la conversación.")
        } catch (e: Exception) {
            reply("No he podido enviar la respuesta.")
        }
    }
}
