package app.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Las "manos" de Jarvis: pulsa, escribe, hace scroll y lee la pantalla.
 * Android solo permite esto si activas el servicio en Ajustes > Accesibilidad.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    /** Modo accesibilidad: si está activo, Jarvis lee en voz alta cada pantalla nueva que se abre. */
    @Volatile
    var accessMode = false

    private val handler = Handler(Looper.getMainLooper())
    private var announce: Runnable? = null
    private var lastClickables: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!accessMode || event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (event.packageName?.toString() == packageName) return
        announce?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            val t = readScreen(12)
            if (t.isNotBlank()) Speaker.say(this, t.take(400))
        }
        announce = r
        handler.postDelayed(r, 900)
    }
    override fun onInterrupt() {}

    // ---------- Acciones globales ----------

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun screenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
    fun lockScreen() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    // ---------- Gestos ----------

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    /** dir: "arriba" (ver lo de arriba), "abajo", "izquierda", "derecha". */
    fun swipe(dir: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "abajo" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }   // el dedo sube: aparece lo de abajo
            "arriba" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "izquierda" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "derecha" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 300)
    }

    // ---------- Leer el árbol de la pantalla ----------

    private fun roots(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        try {
            windows.forEach { w -> w.root?.let { list.add(it) } }
        } catch (_: Exception) {
        }
        if (list.isEmpty()) rootInActiveWindow?.let { list.add(it) }
        return list
    }

    private fun walk(node: AccessibilityNodeInfo?, depth: Int, visit: (AccessibilityNodeInfo) -> Unit) {
        if (node == null || depth > 40) return
        visit(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1, visit)
    }

    private fun allNodes(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        roots().forEach { r -> walk(r, 0) { if (it.isVisibleToUser) out.add(it) } }
        return out
    }

    private fun labelOf(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "")

    /** Lo que se ve en pantalla, en orden de lectura, para que Jarvis lo lea en voz alta. */
    fun readScreen(limit: Int = 25): String {
        val seen = LinkedHashSet<String>()
        val items = ArrayList<Pair<Int, String>>()
        val r = Rect()
        for (n in allNodes()) {
            val t = labelOf(n).trim()
            if (t.isEmpty() || t.length > 120) continue
            n.getBoundsInScreen(r)
            items.add((r.top / 40 * 10000 + r.left / 40) to t)
        }
        items.sortedBy { it.first }.forEach { seen.add(it.second) }
        return seen.take(limit).joinToString(". ")
    }

    private fun deepLabel(n: AccessibilityNodeInfo, depth: Int = 0): String {
        val own = labelOf(n).trim()
        if (own.isNotEmpty()) return own
        if (depth >= 3) return ""
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val t = deepLabel(c, depth + 1)
            if (t.isNotEmpty()) return t
        }
        return ""
    }

    /** Numera lo que se puede pulsar: "1: Buscar. 2: Inicio..." Luego "pulsa el 2" lo pulsa. */
    fun listClickables(): String {
        val r = Rect()
        val items = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
        for (n in allNodes()) {
            if (!n.isClickable) continue
            val label = deepLabel(n).take(60)
            if (label.isEmpty()) continue
            n.getBoundsInScreen(r)
            items.add(Triple(r.top / 40 * 10000 + r.left / 40, label, n))
        }
        val sorted = items.sortedBy { it.first }.take(20)
        lastClickables = sorted.map { it.third }
        return sorted.mapIndexed { i, t -> "${i + 1}: ${t.second}" }.joinToString(". ")
    }

    /** Pulsa el elemento número [index] (empezando en 1) de la última lista de listClickables(). */
    fun clickIndex(index: Int): Boolean {
        val n = lastClickables.getOrNull(index - 1) ?: return false
        return press(n)
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = n
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable) return cur
            cur = cur.parent
            hops++
        }
        return null
    }

    private fun press(n: AccessibilityNodeInfo): Boolean {
        clickableAncestor(n)?.let { if (it.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true }
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    /** Pulsa el elemento cuyo texto o descripción coincide con [spoken]. */
    fun clickByText(spoken: String): Boolean {
        val target = Text.norm(spoken)
        if (target.isEmpty()) return false
        var partial: AccessibilityNodeInfo? = null
        for (n in allNodes()) {
            val l = Text.norm(labelOf(n))
            if (l.isEmpty()) continue
            if (l == target) return press(n)
            if (partial == null && (l.contains(target) || (l.length >= 4 && target.contains(l)))) partial = n
        }
        return partial?.let { press(it) } ?: false
    }

    // ---------- Escribir ----------

    private fun focusedInput(): AccessibilityNodeInfo? {
        for (r in roots()) r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let { return it }
        // Si nada tiene el foco, el primer campo editable visible
        return allNodes().firstOrNull { it.isEditable }
    }

    fun typeText(text: String): Boolean {
        val f = focusedInput() ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clearText(): Boolean = typeText("")

    /** Pulsa "intro/buscar" del teclado. */
    fun imeEnter(): Boolean {
        val f = focusedInput() ?: return false
        if (android.os.Build.VERSION.SDK_INT < 30) return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    // ---------- Música en Metrolist ----------

    /**
     * Pulsa el primer resultado de la búsqueda de Metrolist (la fila grande más alta bajo la barra y los filtros).
     * Es una heurística: depende de cómo dibuje Metrolist la lista, hay que probarla en el móvil.
     */
    fun clickFirstResultRow(): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        val r = Rect()
        var best: AccessibilityNodeInfo? = null
        var bestTop = Int.MAX_VALUE
        for (n in allNodes()) {
            if (!n.isClickable) continue
            n.getBoundsInScreen(r)
            val okWidth = r.width() >= w * 0.6f
            val okHeight = r.height() >= h * 0.04f && r.height() <= h * 0.2f
            val okTop = r.top >= h * 0.2f
            if (okWidth && okHeight && okTop && r.top < bestTop) {
                best = n
                bestTop = r.top
            }
        }
        return best?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }
}
