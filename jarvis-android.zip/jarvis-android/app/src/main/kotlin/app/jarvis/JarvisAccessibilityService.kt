package app.jarvis

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Las "manos" de Jarvis: pulsa, escribe, hace scroll y lee la pantalla.
 * Android solo permite esto si activas el servicio en Ajustes > Accesibilidad.
 */
class JarvisAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: JarvisAccessibilityService? = null
    }

    /** Modo accesibilidad: si está activo, Jarvis lee en voz alta cada pantalla nueva que se abre. */
    @Volatile
    var accessMode = false

    private val handler = Handler(Looper.getMainLooper())
    private var announce: Runnable? = null
    private var lastClickables: List<AccessibilityNodeInfo> = emptyList()

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!accessMode || event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val evPkg = event.packageName?.toString()
        if (evPkg == packageName || evPkg == "com.android.systemui" || evPkg?.contains("inputmethod") == true) return
        announce?.let { handler.removeCallbacks(it) }
        val r = Runnable {
            val t = readScreen(8)
            if (t.isNotBlank()) Speaker.say(this, t.take(300))
        }
        announce = r
        handler.postDelayed(r, 900)
    }
    override fun onInterrupt() {}

    // ---------- Acciones globales ----------

    fun back() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun home() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun recents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications() = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings() = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
    fun screenshot() = performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
    fun lockScreen() = performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)

    // ---------- Gestos ----------

    private fun gesture(path: Path, durationMs: Long): Boolean {
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Float, y: Float): Boolean {
        val p = Path().apply { moveTo(x, y) }
        return gesture(p, 60)
    }

    private fun scrollableNode(): AccessibilityNodeInfo? {
        val r = Rect()
        var best: AccessibilityNodeInfo? = null
        var bestArea = 0
        for (n in allNodes()) {
            if (!n.isScrollable) continue
            n.getBoundsInScreen(r)
            val area = r.width() * r.height()
            if (area > bestArea) { best = n; bestArea = area }
        }
        return best
    }

    /**
     * Desplaza la pantalla. Primero intenta el scroll "de verdad" de la lista visible (más fiable) y, si no hay
     * ninguna, hace el gesto con el dedo. dir: "abajo" (ver lo de abajo), "arriba", "izquierda", "derecha".
     */
    fun swipe(dir: String): Boolean {
        if (dir == "abajo" || dir == "arriba") {
            val n = scrollableNode()
            if (n != null) {
                val act = if (dir == "abajo") AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                if (n.performAction(act)) return true
            }
        }
        return swipeGesture(dir)
    }

    /** Pasa al siguiente vídeo (TikTok, Reels, Shorts): arrastre rápido hacia arriba o abajo. */
    fun flick(up: Boolean): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        if (up) { p.moveTo(w / 2, h * 0.78f); p.lineTo(w / 2, h * 0.22f) } else { p.moveTo(w / 2, h * 0.22f); p.lineTo(w / 2, h * 0.78f) }
        return gesture(p, 140)
    }

    fun tapCenter(): Boolean {
        val m = resources.displayMetrics
        return tap(m.widthPixels / 2f, m.heightPixels * 0.45f)
    }

    fun doubleTapCenter() {
        tapCenter()
        handler.postDelayed({ tapCenter() }, 140)
    }

    fun foregroundPackage(): String? {
        for (r in roots()) r.packageName?.toString()?.let { return it }
        return null
    }

    fun swipeGesture(dir: String): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        val p = Path()
        when (dir) {
            "abajo" -> { p.moveTo(w / 2, h * 0.72f); p.lineTo(w / 2, h * 0.28f) }   // el dedo sube: aparece lo de abajo
            "arriba" -> { p.moveTo(w / 2, h * 0.28f); p.lineTo(w / 2, h * 0.72f) }
            "izquierda" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
            "derecha" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
            else -> return false
        }
        return gesture(p, 300)
    }

    // ---------- Leer el árbol de la pantalla ----------

    private fun roots(): List<AccessibilityNodeInfo> {
        val list = ArrayList<AccessibilityNodeInfo>()
        try {
            windows.forEach { w -> w.root?.let { list.add(it) } }
        } catch (_: Exception) {
        }
        if (list.isEmpty()) rootInActiveWindow?.let { list.add(it) }
        // La ventanita de Jarvis no cuenta: lo que importa es la app que hay debajo
        val others = list.filter { it.packageName?.toString() != packageName }
        return if (others.isNotEmpty()) others else list
    }

    private fun walk(node: AccessibilityNodeInfo?, depth: Int, visit: (AccessibilityNodeInfo) -> Unit) {
        if (node == null || depth > 40) return
        visit(node)
        for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1, visit)
    }

    private fun allNodes(onlyVisible: Boolean = true): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        roots().forEach { r -> walk(r, 0) { if (!onlyVisible || it.isVisibleToUser) out.add(it) } }
        return out
    }

    private fun labelOf(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "")

    /** Solo las ventanas de la app (sin barra de estado, batería, reloj, teclado ni la tarjeta de Jarvis). */
    private fun appRoots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
                val r = w.root ?: continue
                val pkg = r.packageName?.toString()
                if (pkg == packageName || pkg == "com.android.systemui") continue
                out.add(r)
            }
        } catch (_: Exception) {
        }
        if (out.isEmpty()) {
            rootInActiveWindow?.let {
                val pkg = it.packageName?.toString()
                if (pkg != packageName && pkg != "com.android.systemui") out.add(it)
            }
        }
        return out
    }

    /** El texto de la pantalla, línea a línea, en orden de lectura, sin repetidos. */
    fun screenLines(): List<String> {
        fun collect(onlyVisible: Boolean): List<String> {
            val r = Rect()
            val items = ArrayList<Pair<Long, String>>()
            for (root in appRoots()) {
                walk(root, 0) { n ->
                    if (!onlyVisible || n.isVisibleToUser) {
                        val parts = ArrayList<String>()
                        n.text?.toString()?.trim()?.let { if (it.isNotEmpty()) parts.add(it) }
                        n.contentDescription?.toString()?.trim()?.let { if (it.isNotEmpty() && !parts.contains(it)) parts.add(it) }
                        if (parts.isNotEmpty()) {
                            n.getBoundsInScreen(r)
                            items.add((r.top / 30).toLong() * 100000L + r.left / 30 to parts.joinToString(". ").take(300))
                        }
                    }
                }
            }
            val seen = LinkedHashSet<String>()
            items.sortedBy { it.first }.forEach { seen.add(it.second) }
            return seen.toList()
        }
        val visible = collect(true)
        return if (visible.isNotEmpty()) visible else collect(false)
    }

    /** Para leer en voz alta tal cual. */
    fun readScreen(limit: Int = 40): String = screenLines().take(limit).joinToString(". ")

    /** Para pasárselo a Gemini y que lo resuma. */
    fun screenText(maxChars: Int = 6000): String = screenLines().joinToString("\n").take(maxChars)

    private fun deepLabel(n: AccessibilityNodeInfo, depth: Int = 0): String {
        val own = labelOf(n).trim()
        if (own.isNotEmpty()) return own
        if (depth >= 3) return ""
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val t = deepLabel(c, depth + 1)
            if (t.isNotEmpty()) return t
        }
        return ""
    }

    /** Numera lo que se puede pulsar: "1: Buscar. 2: Inicio..." Luego "pulsa el 2" lo pulsa. */
    fun listClickables(): String {
        val r = Rect()
        val items = ArrayList<Triple<Int, String, AccessibilityNodeInfo>>()
        for (n in allNodes()) {
            if (!n.isClickable) continue
            val label = deepLabel(n).take(60)
            if (label.isEmpty()) continue
            n.getBoundsInScreen(r)
            items.add(Triple(r.top / 40 * 10000 + r.left / 40, label, n))
        }
        val sorted = items.sortedBy { it.first }.take(20)
        lastClickables = sorted.map { it.third }
        return sorted.mapIndexed { i, t -> "${i + 1}: ${t.second}" }.joinToString(". ")
    }

    /** Pulsa el elemento número [index] (empezando en 1) de la última lista de listClickables(). */
    fun clickIndex(index: Int): Boolean {
        val n = lastClickables.getOrNull(index - 1) ?: return false
        return press(n)
    }

    private fun clickableAncestor(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        var cur: AccessibilityNodeInfo? = n
        var hops = 0
        while (cur != null && hops < 6) {
            if (cur.isClickable) return cur
            cur = cur.parent
            hops++
        }
        return null
    }

    private fun press(n: AccessibilityNodeInfo): Boolean {
        clickableAncestor(n)?.let { if (it.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true }
        val r = Rect()
        n.getBoundsInScreen(r)
        return tap(r.exactCenterX(), r.exactCenterY())
    }

    /** Pulsa el elemento cuyo texto o descripción coincide con [spoken]. */
    fun clickByText(spoken: String): Boolean {
        val target = Text.norm(spoken)
        if (target.isEmpty()) return false
        var partial: AccessibilityNodeInfo? = null
        for (n in allNodes()) {
            val l = Text.norm(labelOf(n))
            if (l.isEmpty()) continue
            if (l == target) return press(n)
            if (partial == null && (l.contains(target) || (l.length >= 4 && target.contains(l)))) partial = n
        }
        return partial?.let { press(it) } ?: false
    }

    // ---------- Enviar en WhatsApp ----------

    private val waPackages = setOf("com.whatsapp", "com.whatsapp.w4b")
    private val notSend = Regex("voz|voice|grab|record|camara|camera|adjunt|attach|emoji|sticker|gif|llamada|call|video")

    /**
     * Pulsa el botón de enviar de WhatsApp (normal o Business). Lo busca de tres formas:
     * por su id, por su descripción ("Enviar") y, si no, por su posición: el botón redondo a la derecha del cuadro de texto.
     * Solo pulsa si hay texto escrito en el cuadro (si no, ese botón es el del micrófono).
     */
    fun clickSend(): Boolean {
        val nodes = allNodes().filter { it.packageName?.toString() in waPackages }
        if (nodes.isEmpty()) return false
        // 1) por id
        for (n in nodes) {
            val id = n.viewIdResourceName ?: continue
            if (id.endsWith(":id/send")) return press(n)
        }
        // 2) por descripción
        for (n in nodes) {
            val l = Text.norm(labelOf(n))
            if (l == "enviar" || l == "send" || l == "enviar mensaje") return press(n)
        }
        // 3) por posición, junto al cuadro de texto
        val entry = nodes.firstOrNull { it.isEditable && !it.isShowingHintText && !(it.text?.toString().isNullOrEmpty()) } ?: return false
        val er = Rect()
        entry.getBoundsInScreen(er)
        val r = Rect()
        var best: AccessibilityNodeInfo? = null
        var bestLeft = -1
        for (n in nodes) {
            if (!n.isClickable || n === entry) continue
            n.getBoundsInScreen(r)
            val sameRow = r.centerY() in er.top..er.bottom
            val rightOf = r.left >= er.right - 8
            if (sameRow && rightOf && !notSend.containsMatchIn(Text.norm(labelOf(n))) && r.left > bestLeft) {
                best = n
                bestLeft = r.left
            }
        }
        return best?.let { press(it) } ?: false
    }

    // ---------- Escribir ----------

    private fun focusedInput(): AccessibilityNodeInfo? {
        for (r in roots()) r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.let { return it }
        // Si nada tiene el foco, el primer campo editable visible
        return allNodes().firstOrNull { it.isEditable }
    }

    fun typeText(text: String): Boolean {
        val f = focusedInput() ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun clearText(): Boolean = typeText("")

    /** Añade [text] al final de lo que ya hay escrito en el campo (para dictar). [glue] = pegar sin espacio (signos). */
    fun appendText(text: String, glue: Boolean = false): Boolean {
        val f = focusedInput() ?: return false
        val cur = if (f.isShowingHintText) "" else f.text?.toString().orEmpty()
        val sep = if (cur.isEmpty() || glue || cur.endsWith(" ") || cur.endsWith("\n") || text.startsWith("\n")) "" else " "
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, cur + sep + text)
        }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    /** Pulsa "intro/buscar" del teclado. */
    fun imeEnter(): Boolean {
        val f = focusedInput() ?: return false
        if (android.os.Build.VERSION.SDK_INT < 30) return false
        return f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    // ---------- Música en Metrolist ----------

    /**
     * Pulsa el primer resultado de la búsqueda de Metrolist (la fila grande más alta bajo la barra y los filtros).
     * Es una heurística: depende de cómo dibuje Metrolist la lista, hay que probarla en el móvil.
     */
    fun clickFirstResultRow(): Boolean {
        val m = resources.displayMetrics
        val w = m.widthPixels
        val h = m.heightPixels
        val r = Rect()
        var best: AccessibilityNodeInfo? = null
        var bestTop = Int.MAX_VALUE
        for (n in allNodes()) {
            if (!n.isClickable) continue
            n.getBoundsInScreen(r)
            val okWidth = r.width() >= w * 0.6f
            val okHeight = r.height() >= h * 0.04f && r.height() <= h * 0.2f
            val okTop = r.top >= h * 0.2f
            if (okWidth && okHeight && okTop && r.top < bestTop) {
                best = n
                bestTop = r.top
            }
        }
        return best?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }
}
