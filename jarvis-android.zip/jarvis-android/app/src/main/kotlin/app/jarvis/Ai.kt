package app.jarvis

import android.content.Context
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Plan B de Jarvis: si ninguna regla entiende la frase, se la pasa a Gemini junto con la lista de cosas que Jarvis
 * sabe hacer. Gemini contesta con un JSON ("haz esto") y Jarvis lo ejecuta con su código de siempre.
 */
object Ai {
    private val history = ArrayList<Pair<String, String>>() // (rol, texto)
    private var lastUse = 0L

    private fun now(): String =
        SimpleDateFormat("EEEE d 'de' MMMM 'de' yyyy, HH:mm", Locale("es", "ES")).format(Date()) +
            " (zona " + TimeZone.getDefault().id + ")"

    private fun system(): String = """
Eres Jarvis, el asistente de voz del móvil Android de Marc. Hablas en español de España, natural y MUY breve: tus frases se leen en voz alta, así que 1 o 2 frases, sin listas, sin markdown, sin emojis.
Fecha y hora actuales: ${now()}.
Recibes lo que dice el usuario, transcrito por voz (puede tener errores de reconocimiento: interpreta lo que quiso decir). Decide qué hacer y responde SIEMPRE con UN solo objeto JSON, sin nada fuera del JSON.

Tipos de respuesta:
1) {"type":"command","text":"<orden>"}  -> ejecutar una orden del móvil. <orden> debe tener EXACTAMENTE una de estas formas:
   abre <app> | pon <canción o artista> (en Metrolist) | llama a <nombre o número> | pausa | continúa | siguiente | anterior |
   siguiente vídeo | vídeo anterior | dale like | sube el volumen | baja el volumen | silencia | enciende la linterna | apaga la linterna |
   pon un temporizador de <n> minutos | pon una alarma a las <H> y <M> | llévame a <lugar> | qué hora es | qué día es hoy |
   qué tiempo hace en <ciudad> | qué tiempo hace mañana en <ciudad> | cuánto es <operación> | lee mis mensajes | lee mis notificaciones |
   lee la pantalla | atrás | inicio | baja | sube | haz una captura | busca <consulta en Google> | busca vídeos de <tema> en newpipe |
   activa modo pantalla rota | cuánta batería queda | lee mis notas | qué recordatorios tengo
2) {"type":"send_message","channel":"whatsapp"|"sms","contact":"<nombre tal como lo dijo>","message":"<texto a enviar, o cadena vacía si no lo dijo>"}
   -> mandar un mensaje a alguien. Redacta el mensaje en primera persona tal como lo diría el usuario ("ya voy", "llego en 10 minutos"), corrigiendo errores de transcripción. Si no dijo qué enviar, deja message vacío (Jarvis se lo preguntará).
3) {"type":"reply_notification","contact":"<nombre o vacío>","message":"<texto>"}  -> contestar a un mensaje que le acaba de llegar (si dice "dile que...", "contéstale...").
4) {"type":"reminder","text":"<qué recordar, con verbo en infinitivo>","when":"yyyy-MM-ddTHH:mm"}  -> recordatorio con fecha y hora ya calculadas a partir de la fecha actual. Si falta la hora, pregúntala con un "say".
5) {"type":"note","text":"<texto>"}  -> apuntar una nota.
6) {"type":"say","text":"<lo que dices>","expect_reply":false}  -> responder preguntas de conocimiento, charlar, o decir que no puedes. Si necesitas un dato que falta o haces una pregunta y esperas contestación, pon "expect_reply":true.

Reglas: si la frase es una pregunta o charla, usa "say". Nunca inventes datos del móvil del usuario (contactos, mensajes, calendario). Para el tiempo meteorológico usa SIEMPRE el command (tienes datos reales). Si no sabes qué quiere, usa "say" preguntando con expect_reply true.
""".trimIndent()

    /** Procesa [raw] con Gemini. [reply] se llama (en el hilo principal) con lo que Jarvis debe decir. */
    fun run(ctx: Context, raw: String, reply: (String) -> Unit) {
        val app = ctx.applicationContext
        if (!Gemini.configured(app)) { reply("No tengo configurada la IA. Pon la clave de Gemini en los ajustes de Jarvis."); return }
        val t = System.currentTimeMillis()
        if (t - lastUse > 180_000) history.clear()
        lastUse = t
        history.add("user" to raw)
        while (history.size > 12) history.removeAt(0)
        // El primer turno enviado debe ser del usuario
        while (history.isNotEmpty() && history[0].first != "user") history.removeAt(0)
        val turns = ArrayList(history)

        Net.background({ Gemini.generate(app, system(), turns, true) }) { text, err ->
            if (err != null || text == null) {
                history.removeAt(history.size - 1)
                reply(if (err != null) Gemini.explain(err) else "No he podido hablar con Gemini.")
                return@background
            }
            history.add("model" to text)
            val json = parse(text)
            if (json == null) {
                // No era JSON: lo tomamos como respuesta hablada
                reply(text.take(500))
            } else {
                dispatch(app, raw, json, reply)
            }
        }
    }

    private fun parse(text: String): JSONObject? {
        val a = text.indexOf('{')
        val b = text.lastIndexOf('}')
        if (a < 0 || b <= a) return null
        return try { JSONObject(text.substring(a, b + 1)) } catch (e: Exception) { null }
    }

    private fun dispatch(ctx: Context, raw: String, j: JSONObject, reply: (String) -> Unit) {
        when (j.optString("type")) {
            "say" -> {
                val say = j.optString("text").ifBlank { "No sé qué decir a eso." }
                if (j.optBoolean("expect_reply", false)) {
                    Conversation.ask { c, answer, r -> run(c, answer, r) }
                }
                reply(say)
            }
            "command" -> {
                val cmd = j.optString("text")
                if (cmd.isBlank()) reply("No sé hacer eso todavía.")
                else CommandEngine.handle(ctx, cmd, false, reply, fromAi = true)
            }
            "send_message" -> {
                val channel = if (j.optString("channel").equals("sms", true)) "sms" else "whatsapp"
                val who = j.optString("contact").trim()
                if (who.isEmpty()) { reply("¿A quién se lo mando?"); Conversation.ask { c, a, r -> Messaging.start(c, channel, a, j.optString("message").takeIf { it.isNotBlank() }, r) }; return }
                Messaging.start(ctx, channel, who, j.optString("message").trim().takeIf { it.isNotEmpty() }, reply)
            }
            "reply_notification" -> {
                val msg = j.optString("message").trim()
                IncomingReply.replyTo(ctx, j.optString("contact").trim().takeIf { it.isNotEmpty() }, msg.takeIf { it.isNotEmpty() }, reply)
            }
            "reminder" -> Reminders.addFromAi(ctx, j.optString("text"), j.optString("when"), reply)
            "note" -> {
                val t = j.optString("text").trim()
                if (t.isEmpty()) reply("¿Qué apunto?") else { Notes.add(ctx, t); reply("Apuntado: $t") }
            }
            else -> reply("No sé hacer eso todavía.")
        }
    }
}
