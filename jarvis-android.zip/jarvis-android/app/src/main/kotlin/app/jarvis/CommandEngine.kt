package app.jarvis

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Aquí está toda la lógica de "qué hago cuando me dices X".
 * Para añadir un comando propio nuevo: copia un bloque `m("...")?.let { ...; return }` y cambia la frase.
 * Las frases se escriben SIN tildes y en minúsculas (el texto oído se normaliza antes de compararlo).
 */
object CommandEngine {
    private val main = Handler(Looper.getMainLooper())
    // El reconocedor a veces oye "Jarvis" como yarvis, jarbis, charvis...
    private val wakeWords = "jarvis|yarvis|jarbis|yarbis|charvis|garvis|harvis|jarvi|yarvi|jarvins"
    private val wake = Regex("^(oye |hey |ey |ok )?($wakeWords) ")
    private val rawWake = Regex("^(oye |hey |ey |ok )?($wakeWords),? +", RegexOption.IGNORE_CASE)
    private var lastReply = ""
    private val jokes = listOf(
        "¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.",
        "¿Qué hace una abeja en el gimnasio? ¡Zum-ba!",
        "Un programador va al súper y su mujer le dice: compra una barra de pan, y si hay huevos, trae seis. Vuelve con seis barras de pan: ¡había huevos!",
        "¿Qué le dice un bit a otro? Nos vemos en el bus.",
        "¿Cómo se llama el campeón de buceo japonés? Tokofondo. ¿Y el subcampeón? Kasitoko."
    )
    private var torchOn = false

    private const val NEED_A11Y = "Activa el servicio de accesibilidad de Jarvis en los ajustes."

    private fun MatchResult.q(): String = (groups["q"]?.value ?: "").trim()

    /**
     * Procesa una frase. [requireWake]: si es true y no empieza por "Jarvis", se ignora (modo pantalla rota).
     * [reply] se llama con lo que Jarvis debe decir (o no se llama si se ignoró la frase).
     */
    fun handle(ctx: Context, raw: String, requireWake: Boolean, replyOut: (String) -> Unit) {
        val reply: (String) -> Unit = { s -> lastReply = s; replyOut(s) }
        var spoken = Text.norm(raw)
        val padded = "$spoken "
        val w = wake.find(padded)
        if (w != null) spoken = padded.substring(w.value.length).trim()
        else if (requireWake) return
        val c = spoken
        if (c.isEmpty()) { reply("Dime."); return }

        fun m(p: String): MatchResult? = Regex(p).matchEntire(c)
        fun withA11y(block: (JarvisAccessibilityService) -> String) {
            val s = JarvisAccessibilityService.instance
            reply(if (s == null) NEED_A11Y else block(s))
        }
        // Lo que dijiste, conservando tildes y mayúsculas, para escribirlo tal cual
        fun rawArg(verbs: String): String =
            raw.trim().replace(rawWake, "").replace(Regex("^($verbs) +", RegexOption.IGNORE_CASE), "").trim()

        // 0) Comandos tuyos (los de la app) tienen prioridad
        CustomCommands.find(ctx, c)?.let { runCustom(ctx, it, reply); return }

        // 1) Modo pantalla rota
        m("(activa |activar |pon |enciende )?(el )?modo (pantalla rota|manos libres|escucha)( continuo)?")?.let {
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                reply("Necesito permiso de micrófono. Abre la app de Jarvis y dáselo.")
            } else {
                ctx.startForegroundService(Intent(ctx, ContinuousService::class.java))
                reply("Modo pantalla rota activado. Di Jarvis y después la orden.")
            }
            return
        }
        m("(desactiva |desactivar |quita |termina |apaga )(el )?modo (pantalla rota|manos libres|escucha)( continuo)?|deja de escuchar|para de escuchar")?.let {
            ctx.stopService(Intent(ctx, ContinuousService::class.java))
            reply("Vale, dejo de escuchar.")
            return
        }

        // 1b) Modo accesibilidad: Jarvis te lee lo que aparece y lo maneja por voz
        m("(desactiva |desactivar |quita |apaga |termina )(el )?(modo )?accesibilidad")?.let {
            JarvisAccessibilityService.instance?.accessMode = false
            reply("Modo accesibilidad desactivado."); return
        }
        m("(activa |activar |pon |enciende )?(el )?(modo )?accesibilidad")?.let {
            val s = JarvisAccessibilityService.instance
            if (s == null) { reply(NEED_A11Y); return }
            s.accessMode = true
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                ctx.startForegroundService(Intent(ctx, ContinuousService::class.java))
            }
            reply("Modo accesibilidad activado. Te leo lo que aparezca en pantalla. Di Jarvis y una orden, por ejemplo: qué botones hay, pulsa el 2, baja, atrás.")
            return
        }
        m("(que botones hay|lee los botones|enumera( los botones)?|numera( los botones)?|que puedo pulsar|opciones)")?.let {
            withA11y { s ->
                val t = s.listClickables()
                if (t.isBlank()) "No veo nada que se pueda pulsar." else t
            }
            return
        }
        m("(pulsa|pulsar|toca|tocar|elige|selecciona|dale a)( el| la)?( numero| opcion| boton)? (?<q>\\d{1,2}|uno|una|dos|tres|cuatro|cinco|seis|siete|ocho|nueve|diez)")?.let {
            val idx = Text.number(it.q()) ?: 0
            withA11y { s -> if (s.clickIndex(idx)) "Pulsado el $idx" else "No hay un botón $idx. Pídeme primero qué botones hay." }
            return
        }
        m("(enviar|envialo|mandalo|mandalo ya|dale a enviar)")?.let {
            withA11y { s -> if (s.clickByText("enviar") || s.clickByText("send")) "Enviado" else "No veo el botón de enviar" }
            return
        }

        // 1c) Cosas de asistente: notificaciones, mensajes, alarmas, rutas, ajustes, juegos
        m("(lee|leeme|dime) (mis |las )?notificaciones|que notificaciones tengo|tengo notificaciones")?.let {
            reply(JarvisNotificationService.summary()); return
        }
        m("(repite|repitelo|que has dicho|que dijiste)")?.let {
            reply(if (lastReply.isEmpty()) "Aún no he dicho nada." else lastReply); return
        }
        m("(abre |ve a |pon |activa )?(los )?(ajustes de )?(?<q>wifi|bluetooth)")?.let {
            val action = if (it.q() == "wifi") Settings.ACTION_WIFI_SETTINGS else Settings.ACTION_BLUETOOTH_SETTINGS
            try {
                ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                reply("Ajustes de ${it.q()}")
            } catch (e: Exception) {
                reply("No he podido abrir esos ajustes.")
            }
            return
        }
        m(".*(alarma|despiertame).* a las .*")?.let { reply(setAlarm(ctx, c)); return }
        m("(llevame|navega|ruta|como llego|como ir|dime como llegar) (a |al |hasta |para )?(?<q>.+)")?.let {
            navigate(ctx, it.q(), reply); return
        }
        m("(manda|envia|mandale|enviale|escribe|escribele) (un |el )?(?<kind>whatsapp|wasap|guasap|mensaje|sms) (a |al )?(?<who>.+?) (?<delim>diciendo|que diga|y dile|dile|con el texto|que) (?<q>.+)")?.let {
            val who = it.groups["who"]!!.value.trim()
            val delim = it.groups["delim"]!!.value
            val kind = it.groups["kind"]!!.value
            val idx = raw.lowercase(Locale("es", "ES")).indexOf(" $delim ")
            val msg = if (idx >= 0) raw.substring(idx + delim.length + 2).trim() else it.q()
            prepareMessage(ctx, kind, who, msg, reply)
            return
        }
        m("(tira|lanza) (un |el )?dado")?.let { reply("Ha salido el " + (1..6).random()); return }
        m("(cara o cruz|tira una moneda|lanza una moneda)")?.let { reply(listOf("Cara", "Cruz").random()); return }
        m("(cuentame |dime |echame )?(un )?chiste")?.let { reply(jokes.random()); return }

        // 2) Control de la música / vídeo que esté sonando (Metrolist, NewPipe...)
        m("(pausa|pausar|para|parar|detente|pausa la musica|para la musica|pausa el video)")?.let {
            mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); reply("Pausado"); return
        }
        m("(continua|continuar|reanuda|reanudar|play|dale al play|sigue|reproduce|sigue la musica)")?.let {
            mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); reply("Sigo"); return
        }
        m("(siguiente|siguiente cancion|pasa|pasa cancion|salta|salta cancion|next)")?.let {
            mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); reply("Siguiente"); return
        }
        m("(anterior|cancion anterior|vuelve a la anterior|previous)")?.let {
            mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); reply("Anterior"); return
        }

        // 3) Cosas del sistema
        m("(sube|subir|aumenta) (el )?volumen")?.let { volume(ctx, true); reply("Volumen arriba"); return }
        m("(baja|bajar|reduce) (el )?volumen")?.let { volume(ctx, false); reply("Volumen abajo"); return }
        m("(pon )?(el )?volumen (al )?(maximo|a tope)|pon el volumen (al )?(maximo|a tope)")?.let {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI)
            reply("Volumen al máximo"); return
        }
        m("(silencia|silenciar|mutea|quita el sonido)( el movil| el volumen)?")?.let {
            ctx.getSystemService(AudioManager::class.java)
                .adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
            reply("Silenciado"); return
        }
        m("(enciende|activa|pon|prende) (la )?(linterna|luz)")?.let {
            reply(if (torch(ctx, true)) "Linterna encendida" else "No he podido encender la linterna"); return
        }
        m("(apaga|desactiva|quita) (la )?(linterna|luz)")?.let {
            reply(if (torch(ctx, false)) "Linterna apagada" else "No he podido apagar la linterna"); return
        }
        m("(pon |ponme |programa |crea |activa )?(un )?temporizador( de| a| para)? (?<q>.+)")?.let {
            val secs = Text.durationSeconds(it.q())
            if (secs == null || secs <= 0) { reply("No he entendido cuánto tiempo."); return }
            try {
                ctx.startActivity(
                    Intent(AlarmClock.ACTION_SET_TIMER)
                        .putExtra(AlarmClock.EXTRA_LENGTH, secs)
                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                reply("Temporizador puesto")
            } catch (e: Exception) {
                reply("No he podido poner el temporizador.")
            }
            return
        }
        m("(que hora es|dime la hora|la hora|que hora tenemos)")?.let {
            reply("Son las " + SimpleDateFormat("H:mm", Locale("es", "ES")).format(Date())); return
        }
        m("(que dia es( hoy)?|a que dia estamos|dime la fecha|que fecha es)")?.let {
            reply("Hoy es " + SimpleDateFormat("EEEE d 'de' MMMM", Locale("es", "ES")).format(Date())); return
        }
        m(".*bateria.*")?.let {
            val pct = ctx.getSystemService(BatteryManager::class.java)
                .getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            reply("Te queda un $pct por ciento de batería"); return
        }

        // 4) Llamadas
        m("(contesta|contestar|descuelga|coge|coge la llamada|responde|responde la llamada)")?.let {
            reply(answerCall(ctx)); return
        }
        m("(cuelga|colgar|termina la llamada|rechaza|rechaza la llamada)")?.let {
            reply(endCall(ctx)); return
        }
        m("(pon |activa |enciende )?(el )?altavoz")?.let {
            val am = ctx.getSystemService(AudioManager::class.java)
            am.isSpeakerphoneOn = true
            reply("Altavoz activado"); return
        }
        m("(llama|llamar|llamame|telefonea|marca) (a |al |a la )?(?<q>.+)")?.let {
            reply(Apps.call(ctx, it.q())); return
        }

        // 5) Controlar la pantalla (necesita el servicio de accesibilidad)
        m("(atras|vuelve|volver|vuelve atras|ve atras)")?.let { withA11y { s -> s.back(); "Atrás" }; return }
        m("(inicio|ve a inicio|pantalla de inicio|ve al inicio|home|casa)")?.let { withA11y { s -> s.home(); "Inicio" }; return }
        m("(recientes|aplicaciones recientes|abre recientes|multitarea)")?.let { withA11y { s -> s.recents(); "Recientes" }; return }
        m("(notificaciones|abre notificaciones|baja la barra|muestra notificaciones)")?.let { withA11y { s -> s.notifications(); "Notificaciones" }; return }
        m("(ajustes rapidos|abre ajustes rapidos)")?.let { withA11y { s -> s.quickSettings(); "Ajustes rápidos" }; return }
        m("(haz una captura|captura|captura de pantalla|haz captura de pantalla|haz una captura de pantalla)")?.let { withA11y { s -> s.screenshot(); "Captura hecha" }; return }
        m("(bloquea|bloquear|bloquea la pantalla|bloquear pantalla|apaga la pantalla)")?.let { withA11y { s -> s.lockScreen(); "Pantalla bloqueada" }; return }
        m("(baja|desplaza abajo|scroll abajo|mas abajo|baja la pantalla)")?.let { withA11y { s -> s.swipe("abajo"); "Bajo" }; return }
        m("(sube|desplaza arriba|scroll arriba|mas arriba|sube la pantalla)")?.let { withA11y { s -> s.swipe("arriba"); "Subo" }; return }
        m("(desliza |pasa |swipe )(a la )?izquierda")?.let { withA11y { s -> s.swipe("izquierda"); "Deslizo a la izquierda" }; return }
        m("(desliza |pasa |swipe )(a la )?derecha")?.let { withA11y { s -> s.swipe("derecha"); "Deslizo a la derecha" }; return }
        m("(que hay en pantalla|que hay en la pantalla|lee la pantalla|leeme la pantalla|que sale en pantalla|que veo|lee pantalla)")?.let {
            withA11y { s ->
                val t = s.readScreen()
                if (t.isBlank()) "No veo texto en pantalla." else t.take(700)
            }
            return
        }
        m("(pulsa|pulsar|toca|tocar|clica|clic en|haz clic en|haz click en|selecciona|seleccionar|dale a|dale al) (?<q>.+)")?.let {
            val target = it.q().replace(Regex("^(en |el |la |los |las |al |a la |boton |el boton )+"), "")
            withA11y { s -> if (s.clickByText(target)) "Pulsado $target" else "No veo $target en pantalla" }
            return
        }
        m("(escribe|teclea|escribir) (?<q>.+)")?.let {
            val text = rawArg("escribe|teclea|escribir")
            withA11y { s -> if (s.typeText(text)) "Escrito" else "No hay ningún campo de texto" }
            return
        }
        m("(borra|borrar|borra el texto|limpia el campo)")?.let {
            withA11y { s -> if (s.clearText()) "Borrado" else "No hay ningún campo de texto" }
            return
        }
        m("(enter|intro|dale a enter|confirma)")?.let {
            withA11y { s -> if (s.imeEnter()) "Hecho" else "No he podido dar a intro" }
            return
        }

        // 6) Vídeos en NewPipe
        m("busca (en )?newpipe (?<q>.+)")?.let { searchNewPipe(ctx, it.q(), reply); return }
        m("(busca|pon|ponme|abre|muestra) (los |el |un |unos )?(videos|video) (de |sobre |del )?(?<q>.+?)( en newpipe)?")?.let {
            searchNewPipe(ctx, it.q(), reply); return
        }

        // 7) Abrir apps (TikTok, NewPipe, Metrolist, lo que sea)
        m("(abre|abrir|lanza|ejecuta|inicia|abreme|ve a) (la app de |la aplicacion de |la aplicacion |la app |el |la )?(?<q>.+)")?.let {
            val name = it.q()
            val pkg = Apps.resolve(ctx, name)
            reply(if (pkg != null && Apps.launch(ctx, pkg)) "Abriendo $name" else "No encuentro la app $name")
            return
        }

        // 8) Música en Metrolist
        m("(pon|ponme|reproduce|reproduceme|escuchar|quiero escuchar)( la cancion de| la cancion| el tema| la musica de| musica de| algo de| a| de)? (?<q>.+?)( en metrolist)?")?.let {
            playMusic(ctx, it.q(), reply); return
        }

        // 9) Buscar en internet
        m("(busca|buscame|googlea) (en google )?(?<q>.+)")?.let {
            try {
                ctx.startActivity(Intent(Intent.ACTION_WEB_SEARCH).putExtra("query", it.q()).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                reply("Buscando ${it.q()}")
            } catch (e: Exception) {
                reply("No he podido buscar.")
            }
            return
        }

        m("(ayuda|que puedes hacer|que sabes hacer)")?.let {
            reply("Puedo abrir cualquier app, poner música en Metrolist, buscar vídeos en NewPipe, llamar, mandar mensajes, poner alarmas y temporizadores, llevarte a un sitio, leerte las notificaciones y la pantalla, y manejar el móvil por voz con el modo accesibilidad. Prueba: abre WhatsApp, pon Ozuna, llama a mamá, accesibilidad.")
            return
        }

        reply("No te he entendido: $raw")
    }

    // ---------- Implementaciones ----------

    /** Deja el mensaje escrito (WhatsApp o SMS) y espera a que digas "enviar" para no mandar algo mal oído. */
    private fun prepareMessage(ctx: Context, kind: String, who: String, msg: String, reply: (String) -> Unit) {
        val contact = Apps.findContact(ctx, who)
        val number = contact?.second ?: who.filter { it.isDigit() }.takeIf { it.length >= 6 }
        if (number == null) {
            reply(
                if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
                    "Necesito permiso para leer los contactos." else "No encuentro a $who en tus contactos."
            )
            return
        }
        val name = contact?.first ?: who
        val wa = if (kind == "sms") null else Apps.resolve(ctx, "whatsapp")
        val i = if (wa != null) {
            Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + Apps.intl(number) + "?text=" + Uri.encode(msg))).setPackage(wa)
        } else {
            Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(number))).putExtra("sms_body", msg)
        }
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            reply("No he podido abrir la app de mensajes."); return
        }
        reply("Mensaje para $name: $msg. Di enviar para mandarlo.")
    }

    private fun setAlarm(ctx: Context, c: String): String {
        val m = Regex("a las (\\d{1,2})(?: y (media|cuarto)| menos cuarto| (\\d{2}))?(?: de la (manana|tarde|noche))?").find(c)
            ?: return "No he entendido la hora."
        var h = m.groupValues[1].toInt()
        var min = 0
        when {
            m.groupValues[2] == "media" -> min = 30
            m.groupValues[2] == "cuarto" -> min = 15
            m.value.contains("menos cuarto") -> { min = 45; h -= 1 }
            m.groupValues[3].isNotEmpty() -> min = m.groupValues[3].toInt()
        }
        val part = m.groupValues[4]
        if ((part == "tarde" || part == "noche") && h < 12) h += 12
        if (part == "manana" && h == 12) h = 0
        if (h !in 0..23) return "No he entendido la hora."
        return try {
            ctx.startActivity(
                Intent(AlarmClock.ACTION_SET_ALARM)
                    .putExtra(AlarmClock.EXTRA_HOUR, h)
                    .putExtra(AlarmClock.EXTRA_MINUTES, min)
                    .putExtra(AlarmClock.EXTRA_MESSAGE, "Jarvis")
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            "Alarma puesta a las $h:" + min.toString().padStart(2, '0')
        } catch (e: Exception) {
            "No he podido poner la alarma."
        }
    }

    private fun navigate(ctx: Context, dest: String, reply: (String) -> Unit) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)))
                    .setPackage("com.google.android.apps.maps").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            reply("Te llevo a $dest")
        } catch (e: Exception) {
            try {
                ctx.startActivity(
                    Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(dest))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
                reply("Buscando $dest en el mapa")
            } catch (e2: Exception) {
                reply("No he podido abrir ningún mapa.")
            }
        }
    }

    private fun runCustom(ctx: Context, c: Custom, reply: (String) -> Unit) {
        when (c.type) {
            Custom.APP -> {
                val pkg = Apps.resolve(ctx, c.value)
                reply(if (pkg != null && Apps.launch(ctx, pkg)) "Abriendo ${c.value}" else "No encuentro ${c.value}")
            }
            Custom.URL -> try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(c.value)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                reply("Hecho")
            } catch (e: Exception) {
                reply("No he podido abrir el enlace.")
            }
            Custom.CALL -> reply(Apps.call(ctx, c.value))
            else -> reply(c.value)
        }
    }

    /** Envía una tecla multimedia al reproductor activo (el que haya sonado último). */
    private fun mediaKey(ctx: Context, code: Int) {
        val am = ctx.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun volume(ctx: Context, up: Boolean) {
        val am = ctx.getSystemService(AudioManager::class.java)
        val dir = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        for (i in 0 until 3) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, if (i == 2) AudioManager.FLAG_SHOW_UI else 0)
    }

    private fun torch(ctx: Context, on: Boolean): Boolean = try {
        val cm = ctx.getSystemService(CameraManager::class.java)
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) false else { cm.setTorchMode(id, on); torchOn = on; true }
    } catch (e: Exception) {
        false
    }

    private fun answerCall(ctx: Context): String = try {
        ctx.getSystemService(TelecomManager::class.java).acceptRingingCall()
        "Contestando"
    } catch (e: SecurityException) {
        "Necesito el permiso de contestar llamadas."
    } catch (e: Exception) {
        "No he podido contestar."
    }

    private fun endCall(ctx: Context): String = try {
        @Suppress("DEPRECATION")
        val ok = ctx.getSystemService(TelecomManager::class.java).endCall()
        if (ok) "Colgado" else "No hay ninguna llamada."
    } catch (e: SecurityException) {
        "Necesito el permiso de contestar llamadas."
    } catch (e: Exception) {
        "No he podido colgar."
    }

    /**
     * Metrolist no tiene un "reproduce esto" público. Lo que sí hace: abrir una URL de búsqueda de YouTube Music
     * (music.youtube.com/search?q=...). Jarvis la abre en Metrolist y luego pulsa el primer resultado
     * con el servicio de accesibilidad.
     */
    private fun playMusic(ctx: Context, query: String, reply: (String) -> Unit) {
        val pkg = Apps.resolve(ctx, "metrolist")
        if (pkg == null) { reply("No encuentro Metrolist instalado."); return }
        val uri = Uri.parse("https://music.youtube.com/search?q=" + Uri.encode(query))
        val i = Intent(Intent.ACTION_VIEW, uri).setPackage(pkg)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        try {
            ctx.startActivity(i)
        } catch (e: Exception) {
            reply("No he podido abrir Metrolist."); return
        }
        if (JarvisAccessibilityService.instance == null) {
            reply("He abierto la búsqueda de $query en Metrolist. Para que le dé al play yo solo, activa la accesibilidad de Jarvis.")
            return
        }
        reply("Poniendo $query en Metrolist")
        clickResultWithRetries(0)
    }

    private fun clickResultWithRetries(attempt: Int) {
        main.postDelayed({
            val s = JarvisAccessibilityService.instance
            if (s != null && !s.clickFirstResultRow() && attempt < 6) clickResultWithRetries(attempt + 1)
        }, if (attempt == 0) 2500L else 1200L)
    }

    /**
     * NewPipe NO abre enlaces de búsqueda de YouTube (/results), así que se hace a mano:
     * abre NewPipe, pulsa la lupa, escribe y da a intro.
     */
    private fun searchNewPipe(ctx: Context, query: String, reply: (String) -> Unit) {
        val pkg = Apps.resolve(ctx, "newpipe")
        if (pkg == null) { reply("No encuentro NewPipe."); return }
        Apps.launch(ctx, pkg)
        val s = JarvisAccessibilityService.instance
        if (s == null) { reply("He abierto NewPipe. Para buscar yo solo, activa la accesibilidad de Jarvis."); return }
        reply("Buscando $query en NewPipe")
        main.postDelayed({
            if (!s.clickByText("buscar")) s.clickByText("search")
            main.postDelayed({
                s.typeText(query)
                main.postDelayed({ if (!s.imeEnter()) s.clickByText("buscar") }, 600L)
            }, 1000L)
        }, 2200L)
    }
}
