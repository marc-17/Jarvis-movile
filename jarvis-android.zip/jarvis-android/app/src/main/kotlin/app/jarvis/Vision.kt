package app.jarvis

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper

/**
 * Hace una foto con la cámara trasera SIN abrir ninguna pantalla de cámara (Camera2 a pelo), para preguntarle
 * a Gemini "¿qué es esto?". Solo funciona con Jarvis a la vista (invocado con el botón de encendido):
 * Android no deja usar la cámara desde segundo plano.
 */
object Vision {
    private val main = Handler(Looper.getMainLooper())

    /** [done] se llama en el hilo principal con (bytes JPEG, null) o (null, motivo del fallo). */
    fun capture(ctx: Context, done: (ByteArray?, String?) -> Unit) {
        val app = ctx.applicationContext
        if (app.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            done(null, "Necesito el permiso de cámara. Dámelo en la app de Jarvis.")
            return
        }
        val cm = app.getSystemService(CameraManager::class.java)
        val camId: String
        val chars: CameraCharacteristics
        try {
            camId = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: cm.cameraIdList.firstOrNull() ?: run { done(null, "Este móvil no tiene cámara."); return }
            chars = cm.getCameraCharacteristics(camId)
        } catch (e: Exception) {
            done(null, "No he podido acceder a la cámara.")
            return
        }
        val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        if (map == null) { done(null, "No he podido leer la cámara."); return }
        val jpegSize = map.getOutputSizes(ImageFormat.JPEG).filter { it.width <= 1600 }.maxByOrNull { it.width * it.height }
            ?: map.getOutputSizes(ImageFormat.JPEG).minByOrNull { it.width * it.height }!!
        val yuvSize = map.getOutputSizes(ImageFormat.YUV_420_888).filter { it.width <= 1280 }.maxByOrNull { it.width * it.height }
            ?: map.getOutputSizes(ImageFormat.YUV_420_888).minByOrNull { it.width * it.height }!!
        val orientation = chars.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90

        val thread = HandlerThread("jarvis-cam").also { it.start() }
        val handler = Handler(thread.looper)
        val jpegReader = ImageReader.newInstance(jpegSize.width, jpegSize.height, ImageFormat.JPEG, 2)
        val yuvReader = ImageReader.newInstance(yuvSize.width, yuvSize.height, ImageFormat.YUV_420_888, 2)

        var device: CameraDevice? = null
        var session: CameraCaptureSession? = null
        var finished = false

        fun finish(bytes: ByteArray?, error: String?) {
            if (finished) return
            finished = true
            try { session?.close() } catch (_: Exception) {}
            try { device?.close() } catch (_: Exception) {}
            try { jpegReader.close() } catch (_: Exception) {}
            try { yuvReader.close() } catch (_: Exception) {}
            thread.quitSafely()
            main.post { done(bytes, if (bytes == null) (error ?: "No he podido hacer la foto.") else null) }
        }

        yuvReader.setOnImageAvailableListener({ r -> try { r.acquireLatestImage()?.close() } catch (_: Exception) {} }, handler)
        jpegReader.setOnImageAvailableListener({ r ->
            try {
                val img = r.acquireLatestImage()
                if (img != null) {
                    val buf = img.planes[0].buffer
                    val bytes = ByteArray(buf.remaining())
                    buf.get(bytes)
                    img.close()
                    finish(bytes, null)
                }
            } catch (e: Exception) {
                finish(null, "No he podido leer la foto.")
            }
        }, handler)

        main.postDelayed({ finish(null, "La cámara ha tardado demasiado.") }, 9000)

        try {
            @Suppress("MissingPermission")
            cm.openCamera(camId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    device = camera
                    try {
                        @Suppress("DEPRECATION")
                        camera.createCaptureSession(listOf(yuvReader.surface, jpegReader.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(s: CameraCaptureSession) {
                                session = s
                                try {
                                    val preview = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                                        addTarget(yuvReader.surface)
                                        set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                    }
                                    s.setRepeatingRequest(preview.build(), null, handler)
                                    // Un segundo para que enfoque y ajuste la luz, y entonces la foto
                                    handler.postDelayed({
                                        try {
                                            val still = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                                                addTarget(jpegReader.surface)
                                                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                                                set(CaptureRequest.JPEG_ORIENTATION, orientation)
                                                set(CaptureRequest.JPEG_QUALITY, 85.toByte())
                                            }
                                            s.capture(still.build(), null, handler)
                                        } catch (e: Exception) {
                                            finish(null, "No he podido hacer la foto.")
                                        }
                                    }, 1100)
                                } catch (e: Exception) {
                                    finish(null, "No he podido empezar la foto.")
                                }
                            }

                            override fun onConfigureFailed(s: CameraCaptureSession) {
                                finish(null, "La cámara no se ha configurado.")
                            }
                        }, handler)
                    } catch (e: Exception) {
                        finish(null, "No he podido preparar la cámara.")
                    }
                }

                override fun onDisconnected(camera: CameraDevice) {
                    device = camera
                    finish(null, "La cámara se ha desconectado. Puede que otra app la esté usando.")
                }

                override fun onError(camera: CameraDevice, error: Int) {
                    device = camera
                    finish(null, "No puedo usar la cámara ahora. Invócame con el botón de encendido para usarla.")
                }
            }, handler)
        } catch (e: CameraAccessException) {
            finish(null, "No puedo usar la cámara ahora. Invócame con el botón de encendido para usarla.")
        } catch (e: SecurityException) {
            finish(null, "Necesito el permiso de cámara.")
        } catch (e: Exception) {
            finish(null, "No he podido abrir la cámara.")
        }
    }
}
