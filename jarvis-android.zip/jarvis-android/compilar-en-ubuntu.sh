#!/usr/bin/env bash
# Compila Jarvis en Ubuntu sin Android Studio: instala Java 17, el Android SDK (solo línea de comandos)
# y Gradle 8.7, y genera la APK. Necesita ~4 GB libres y internet. Tarda unos minutos la primera vez.
# Uso:  chmod +x compilar-en-ubuntu.sh && ./compilar-en-ubuntu.sh
set -euo pipefail
cd "$(dirname "$0")"

sudo apt-get update
sudo apt-get install -y openjdk-17-jdk unzip wget

SDK="$HOME/android-sdk"
mkdir -p "$SDK/cmdline-tools"
if [ ! -d "$SDK/cmdline-tools/latest" ]; then
  wget -O /tmp/cmdtools.zip https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
  unzip -q /tmp/cmdtools.zip -d "$SDK/cmdline-tools"
  mv "$SDK/cmdline-tools/cmdline-tools" "$SDK/cmdline-tools/latest"
fi
export ANDROID_HOME="$SDK"

yes | "$SDK/cmdline-tools/latest/bin/sdkmanager" --licenses > /dev/null || true
"$SDK/cmdline-tools/latest/bin/sdkmanager" "platform-tools" "platforms;android-34" "build-tools;34.0.0"

GRADLE="$HOME/gradle-8.7"
if [ ! -d "$GRADLE" ]; then
  wget -O /tmp/gradle.zip https://services.gradle.org/distributions/gradle-8.7-bin.zip
  unzip -q /tmp/gradle.zip -d "$HOME"
fi

echo "sdk.dir=$SDK" > local.properties
"$GRADLE/bin/gradle" assembleDebug --no-daemon

echo
echo "LISTO. La APK está en: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
