# Jarvis (asistente de voz para Android)

App sin Claude ni internet propio: escucha con el reconocedor de voz del móvil y ejecuta comandos tuyos
(abrir apps, llamar, música en Metrolist, controlar la pantalla...). Sin dependencias, solo APIs de Android.

> Estado: **sin compilar ni probar en un móvil**. Lo normal es que al compilar salga algún error pequeño de Kotlin
> y que haya que ajustar cosas en el móvil real (sobre todo "pulsar el primer resultado de Metrolist").

## 1. Compilar la APK (la forma fácil: GitHub)
1. Crea un repositorio en GitHub (privado vale) y sube **todo el contenido de esta carpeta**.
2. Pestaña **Actions** → "Compilar APK" → **Run workflow**.
3. Cuando acabe, en esa ejecución baja el artefacto `jarvis-apk` → dentro está `app-debug.apk`.
4. Pásalo al móvil e instálalo (permite "instalar apps desconocidas" para el navegador/gestor de archivos).

Si prefieres local: Android Studio → abrir carpeta → Build > Build APK. (Pesa mucho para 8 GB de RAM.)

## 2. Configurar (todo desde la app, botones 1-5)
1. **Permisos**: micrófono, llamadas, contactos, contestar llamadas, notificaciones.
2. **Accesibilidad**: Ajustes → Accesibilidad → Jarvis → activar.
3. **Notificaciones**: acceso a notificaciones → Jarvis (para "lee mis notificaciones").
4. **Sobre otras apps**: permiso para abrir apps desde el modo pantalla rota.
5. **Asistente**: Ajustes → Apps predeterminadas → Asistente digital → Jarvis.
   - **Ajustes restringidos**: al ser una APK de fuera de la tienda, Android puede bloquear 2 y 3. Ficha de la app → ⋮ → "Permitir ajustes restringidos", y repites.
6. **Botón de encendido**: en Ajustes busca "mantener pulsado botón de encendido" (en Xiaomi suele estar en Ajustes adicionales) y elige "Asistente digital". El tiempo de pulsación (0,5 s) lo decide el sistema, no la app.
7. **Xiaomi/HyperOS**: batería de Jarvis en "Sin restricciones", activar "Inicio automático" y "Mostrar ventanas emergentes en segundo plano", y fijar la app en recientes (candado), o el sistema la matará.

## 3. Cómo se usa
- **Invocar**: mantén el botón de encendido → "Te escucho…" → dices la orden.
- **Modo pantalla rota**: di "activar modo pantalla rota". Se queda escuchando en segundo plano (notificación fija) y solo hace caso a frases que empiecen por **"Jarvis"**. Para parar: "Jarvis, desactiva modo pantalla rota" o el botón Parar de la notificación.
- **Modo accesibilidad**: di "accesibilidad". Activa la escucha continua y lee en voz alta cada pantalla nueva. Con "qué botones hay" los numera y con "pulsa el 3" lo pulsa.
- **Mensajes**: "manda un whatsapp a Marcos diciendo ya voy" deja el mensaje escrito; **tú dices "enviar"** para mandarlo (así no se manda algo mal oído).

## 4. Comandos
Abrir apps: `abre WhatsApp / Metrolist / TikTok / NewPipe / lo que sea` · Música: `pon <canción>` (abre la búsqueda en Metrolist y pulsa el primer resultado), `pausa`, `siguiente`, `anterior`, `continúa` · Llamadas: `llama a <contacto|número>`, `contesta`, `cuelga`, `altavoz` · Vídeos: `busca vídeos de <algo>` (NewPipe) · Pantalla: `lee la pantalla`, `qué botones hay`, `pulsa <texto>`, `pulsa el 2`, `baja`, `sube`, `desliza a la izquierda`, `atrás`, `inicio`, `recientes`, `notificaciones`, `ajustes rápidos`, `captura`, `bloquea` · Texto: `escribe <texto>`, `borra`, `intro`, `enviar` · Asistente: `lee mis notificaciones`, `repite`, `alarma a las 7 y media`, `temporizador de 5 minutos`, `llévame a <sitio>`, `linterna`, `volumen`, `wifi`, `bluetooth`, `qué hora es`, `qué día es`, `cuánta batería`, `chiste`, `dado`, `cara o cruz`.
Tus propios comandos se añaden en la app (frase → abrir app / enlace / llamar / decir).

Para meter comandos nuevos en el código: `CommandEngine.kt`, copia un bloque `m("frase")?.let { ...; return }`. Las frases van sin tildes y en minúsculas.

## 5. Límites reales
- Con el móvil bloqueado con PIN, Jarvis **no puede desbloquearlo**. Para pantalla rota, déjalo desbloqueado/sin bloqueo o con otro método que puedas hacer sin ver.
- Lo que oye depende del reconocedor del móvil (idealmente con el paquete de español descargado para ir offline). Algunos hacen un "pitido" al reiniciar la escucha.
- Metrolist no tiene un "reproduce esto" para otras apps: se usa su enlace de búsqueda + accesibilidad. NewPipe no abre búsquedas por enlace: se hace con lupa + escribir + intro. Ambos son frágiles si cambian sus pantallas.
- Apps bancarias o con pantalla protegida pueden bloquear la lectura/pulsado por accesibilidad.

## 6. Versión 0.2: conversación, IA, mensajes, recordatorios...

- **Conversación**: si Jarvis te pregunta algo (por ejemplo «¿Qué le pongo?»), sigue escuchando tu respuesta sin que tengas que invocarlo otra vez. Di «cancela» o «déjalo» para salir.
- **WhatsApp**: «envía un whatsapp a mamá» → «¿Qué le pongo?» → «ya voy» → «¿Lo envío?» → «sí». Lo envía solo pulsando el botón de enviar (hace falta la accesibilidad de Jarvis). Se puede quitar la confirmación en los ajustes.
- **Mensajes recibidos**: «lee mis mensajes», «dile que ahora voy», «responde a Marcos que sí» (contesta con el botón Responder de la notificación; hace falta el acceso a notificaciones).
- **IA (Gemini)**: pega tu clave en los ajustes de la app (la sacas gratis en aistudio.google.com/apikey). La clave NO está en el código ni en GitHub: se guarda solo en el móvil. Si Jarvis no entiende una frase, se la pasa a Gemini, que charla, contesta preguntas o decide qué hacer.
- **Tiempo y cuentas**: «qué tiempo hace», «qué tiempo hace mañana en Madrid», «cuánto es 25 por 4».
- **TikTok**: «siguiente vídeo», «vídeo anterior», «dale like», «pausa».
- **Rutinas**: «crea una rutina buenas noches» y luego dices los pasos separados por «luego»; o créalas en la app.
- **Recordatorios**: «recuérdame mañana a las 9 llamar a Marcos».
- **Notas**: «apunta comprar tornillos», «lee mis notas».
- **Firma fija**: la APK va firmada siempre con la misma clave, así que desde esta versión las actualizaciones se instalan encima sin perder permisos. (La primera vez hay que desinstalar la versión antigua.)
